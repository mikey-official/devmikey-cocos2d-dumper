#!/usr/bin/env bash
# Cocos2d Dumper - Fast Standalone Binary Launcher
# Works on Linux, macOS, and Android (Termux)

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

# 1. Check for standalone pre-built executable
if [ -f "$SCRIPT_DIR/dumper" ]; then
    chmod +x "$SCRIPT_DIR/dumper" 2>/dev/null
    exec "$SCRIPT_DIR/dumper" "$@"
fi

if [ -f "$SCRIPT_DIR/target/release/dumper" ]; then
    chmod +x "$SCRIPT_DIR/target/release/dumper" 2>/dev/null
    exec "$SCRIPT_DIR/target/release/dumper" "$@"
fi

# 2. Delegate to Rust compiler script if binary not present
echo "[*] Standalone 'dumper' executable not found."
echo "[*] Delegating to Rust compiler script (run_rust.sh)..."
exec bash "$SCRIPT_DIR/run_rust.sh" "$@"
