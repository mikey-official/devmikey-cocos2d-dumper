@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ------------------------------------------------------------
echo   Cocos2d Dumper - Native Rust Compiler and Launcher
echo ------------------------------------------------------------
echo.

:: 1. Load saved custom environment if previously created
if exist "%~dp0cargo_env.bat" (
    call "%~dp0cargo_env.bat"
)

:: 2. Check if cargo is in active PATH
where cargo >nul 2>nul
if %errorlevel% equ 0 (
    goto :run_cargo
)

:: 3. Check standard Windows user Cargo directory (~/.cargo/bin)
if exist "%USERPROFILE%\.cargo\bin\cargo.exe" (
    set "PATH=%USERPROFILE%\.cargo\bin;!PATH!"
    goto :run_cargo
)

:: 4. Check CARGO_HOME environment variable if defined
if defined CARGO_HOME (
    if exist "%CARGO_HOME%\bin\cargo.exe" (
        set "PATH=%CARGO_HOME%\bin;!PATH!"
        goto :run_cargo
    )
)

:: 5. Check common installation directories
if exist "C:\Cargo\bin\cargo.exe" (
    set "PATH=C:\Cargo\bin;!PATH!"
    goto :run_cargo
)
if exist "D:\rust\cargo\bin\cargo.exe" (
    set "PATH=D:\rust\cargo\bin;!PATH!"
    goto :run_cargo
)

:: 6. Cargo was not found automatically - prompt user for their custom path
echo [!] Cargo (Rust compiler) was not detected in system PATH.
echo.
echo If you installed Rust in a custom folder, enter the path below
echo (for example: D:\rust\cargo\bin or D:\rust).
echo You can also drag-and-drop your cargo folder into this window.
echo.
echo Or press ENTER to automatically open https://rustup.rs to install Rust.
echo.
set /p USER_RUST_PATH="Enter Rust/Cargo path (or press Enter to install): "

if "!USER_RUST_PATH!"=="" (
    goto :offer_install
)

:: Clean quotes from user input
set "USER_RUST_PATH=!USER_RUST_PATH:"=!"
set "USER_RUST_PATH=!USER_RUST_PATH:'=!"

:: Check direct path or path\bin
set "TEST_CARGO=!USER_RUST_PATH!\cargo.exe"
if exist "!TEST_CARGO!" (
    set "VALID_BIN=!USER_RUST_PATH!"
    goto :save_and_run
)

set "TEST_CARGO=!USER_RUST_PATH!\bin\cargo.exe"
if exist "!TEST_CARGO!" (
    set "VALID_BIN=!USER_RUST_PATH!\bin"
    goto :save_and_run
)

echo.
echo [!] Could not locate cargo.exe at '!USER_RUST_PATH!'.
echo.
goto :offer_install

:save_and_run
echo [*] Located Cargo at: !VALID_BIN!
echo [*] Saving this configuration to cargo_env.bat so you won't need to re-enter it...
(
    echo @echo off
    echo set "PATH=!VALID_BIN!;%%PATH%%"
) > "%~dp0cargo_env.bat"
set "PATH=!VALID_BIN!;!PATH!"
echo [*] Configuration saved successfully.
echo.
goto :run_cargo

:offer_install
echo.
echo To build from source, install the official Rust toolchain:
echo 1. Download rustup-init from https://rustup.rs
echo 2. Choose option 1 (default installation)
echo 3. Re-run this script after installation completes.
echo.
set /p OPEN_WEB="Open https://rustup.rs in browser now? (Y/N): "
if /i "!OPEN_WEB!"=="Y" (
    start https://rustup.rs
)
if "%~1"=="" pause
exit /b 1

:run_cargo
echo [*] Compiling and running Cocos2d Dumper via Cargo...
echo [*] Directory: %CD%
echo.
cargo run --release -- %*
set "EXIT_CODE=%errorlevel%"

if %EXIT_CODE% neq 0 (
    echo.
    echo [!] Process exited with status code %EXIT_CODE%.
)

if "%~1"=="" pause
exit /b %EXIT_CODE%
