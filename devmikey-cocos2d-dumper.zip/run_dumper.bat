@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

:: Check if pre-compiled standalone dumper.exe exists
if exist "%~dp0dumper.exe" (
    "%~dp0dumper.exe" %*
    if "%~1"=="" pause
    goto :eof
)

if exist "%~dp0target\release\dumper.exe" (
    "%~dp0target\release\dumper.exe" %*
    if "%~1"=="" pause
    goto :eof
)

:: Otherwise delegate to Rust build script
echo [*] Standalone dumper.exe not found in directory.
echo [*] Delegating to Rust compiler script (run_rust.bat)...
call "%~dp0run_rust.bat" %*
if "%~1"=="" pause
