#![allow(dead_code, unused_variables, unused_imports)]

use std::collections::{BTreeMap, HashMap, HashSet};
use std::fs::{self, File};
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::time::Instant;
use memmap2::Mmap;
use serde::ser::{SerializeMap, Serializer};
use serde::{Deserialize, Serialize};

// ----------------------------------------------------------------------------
// Data Models & Clean Serialization (Zero Methods)
// ----------------------------------------------------------------------------

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct FieldInfo {
    pub offset: String,
    #[serde(rename = "type")]
    pub field_type: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub access: Option<String>,
}

fn serialize_fields_by_offset<S>(fields: &BTreeMap<String, FieldInfo>, serializer: S) -> Result<S::Ok, S::Error>
where
    S: Serializer,
{
    let mut entries: Vec<(&String, &FieldInfo)> = fields.iter().collect();
    entries.sort_by(|(name_a, info_a), (name_b, info_b)| {
        let off_a = usize::from_str_radix(info_a.offset.trim_start_matches("0x"), 16).unwrap_or(usize::MAX);
        let off_b = usize::from_str_radix(info_b.offset.trim_start_matches("0x"), 16).unwrap_or(usize::MAX);
        off_a.cmp(&off_b).then_with(|| name_a.cmp(name_b))
    });
    let mut map = serializer.serialize_map(Some(entries.len()))?;
    for (k, v) in entries {
        map.serialize_entry(k, v)?;
    }
    map.end()
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ClassEntry {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub vtable: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub sizeof: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub virtual_function_count: Option<usize>,
    #[serde(serialize_with = "serialize_fields_by_offset")]
    pub fields: BTreeMap<String, FieldInfo>,
    /// "class", "struct" or "union" (from DWARF). None = unknown (RTTI/code-only).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub kind: Option<String>,
    /// Enclosing C++ namespace path, e.g. "ui" or "ui::inner". None = global scope.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub namespace: Option<String>,
    /// "public", "protected" or "private" (from DWARF).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub access: Option<String>,
}

impl ClassEntry {
    fn code_only() -> Self {
        ClassEntry {
            vtable: None,
            sizeof: None,
            virtual_function_count: None,
            fields: BTreeMap::new(),
            kind: None,
            namespace: None,
            access: None,
        }
    }
}

/// DWARF DW_AT_accessibility values -> keyword.
fn access_keyword(v: u64) -> Option<&'static str> {
    match v {
        1 => Some("public"),
        2 => Some("protected"),
        3 => Some("private"),
        _ => None,
    }
}

#[derive(Debug, Clone)]
pub struct EnumEntry {
    pub name: String,
    pub values: Vec<(String, i64)>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Arch {
    Arm64,
    X86_64,
    Unknown(u16),
}

impl Arch {
    pub fn name(&self) -> &'static str {
        match self {
            Arch::Arm64 => "arm64",
            Arch::X86_64 => "x64",
            Arch::Unknown(_) => "unknown",
        }
    }
}

pub fn detect_elf_arch(data: &[u8]) -> Option<Arch> {
    if data.len() < 20 || &data[0..4] != b"\x7fELF" {
        return None;
    }
    let e_machine = u16::from_le_bytes(data[18..20].try_into().unwrap());
    match e_machine {
        183 => Some(Arch::Arm64),
        62 => Some(Arch::X86_64),
        other => Some(Arch::Unknown(other)),
    }
}

fn sanitize_cname(name: &str) -> String {
    let mut s = name;
    if let Some(pos) = s.rfind("::") { s = &s[pos + 2..]; }
    if let Some(pos) = s.find('(') { s = &s[..pos]; }
    let mut clean: String = s.chars().map(|c| if c.is_ascii_alphanumeric() || c == '_' { c } else { '_' }).collect();
    while clean.contains("__") { clean = clean.replace("__", "_"); }
    let trimmed = clean.trim_matches('_');
    let mut res = if trimmed.is_empty() { "UnnamedClass".to_string() } else { trimmed.to_string() };
    if res.chars().next().map_or(false, |c| c.is_ascii_digit()) { res = format!("C_{}", res); }
    if res.len() > 64 { res.truncate(64); }
    res
}

fn sanitize_fname(name: &str) -> String {
    let mut clean: String = name.chars().map(|c| if c.is_ascii_alphanumeric() || c == '_' { c } else { '_' }).collect();
    while clean.contains("__") { clean = clean.replace("__", "_"); }
    let trimmed = clean.trim_matches('_');
    let mut res = if trimmed.is_empty() { "field".to_string() } else { trimmed.to_string() };
    if res.chars().next().map_or(false, |c| c.is_ascii_digit()) { res.insert(0, '_'); }
    res
}

fn s_trailing_stars(s: &str) -> usize {
    s.len() - s.trim_end_matches('*').len()
}

fn simplify_type(raw: &str) -> String {
    let mut s = raw.trim();
    if s.is_empty() { return "void".to_string(); }
    if s.contains("(*)") || s.contains("std::function") || s.contains("func") || (s.contains('(') && s.contains(')')) {
        return "void*".to_string();
    }
    let trailing = s_trailing_stars(raw.trim());
    if trailing > 0 {
        let base = raw.trim().trim_end_matches('*').trim_end();
        return format!("{}{}", simplify_type(base), "*".repeat(trailing));
    }
    if s.starts_with("const ") { s = s[6..].trim(); }

    match s {
        "int" | "int32_t" | "int32" | "i32" | "signed int" => "int".to_string(),
        "unsigned int" | "unsigned" | "uint32_t" | "uint32" | "u32" | "unsigned int32_t" => "uint".to_string(),
        "long long" | "long long int" | "signed long long" | "int64_t" | "int64" | "i64" => "long".to_string(),
        "long" | "long int" | "signed long" | "long signed int" | "isize" => "long".to_string(),
        "unsigned long long" | "unsigned long long int" | "long long unsigned int" | "uint64_t" | "uint64" | "u64" => "ulong".to_string(),
        "unsigned long" | "unsigned long int" | "long unsigned int" | "usize" => "ulong".to_string(),
        "short" | "short int" | "short signed int" | "int16_t" | "i16" => "short".to_string(),
        "unsigned short" | "unsigned short int" | "short unsigned int" | "uint16_t" | "u16" => "ushort".to_string(),
        "char" => "byte".to_string(),
        "signed char" | "int8_t" | "i8" => "sbyte".to_string(),
        "unsigned char" | "uint8_t" | "u8" => "byte".to_string(),
        "bool" | "_Bool" => "bool".to_string(),
        "float" | "f32" => "float".to_string(),
        "double" | "f64" => "double".to_string(),
        "string" | "std::string" => "string".to_string(),
        _ => {
            if s.contains("basic_string<char") { return "string".to_string(); }
            if s.contains('<') { return s.to_string(); }
            if let Some(pos) = s.rfind("::") { s = &s[pos + 2..]; }
            let valid = !s.is_empty() && s.chars().all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '<' || c == '>' || c == '*' || c == ' ');
            if valid { sanitize_cname(s) } else { "IntPtr".to_string() }
        }
    }
}

fn is_stl_junk(s: &str) -> bool {
    if s.is_empty() || s.starts_with("__") || s.contains("<lambda") { return true; }
    if s.starts_with("std::") || s.starts_with("std___") || s.contains("__ndk1") || s.contains("__1::") { return true; }
    const STL_PREFIXES: &[&str] = &[
        "allocator<", "iterator<", "basic_string<", "char_traits<",
        "pair<", "tuple<", "integral_constant<", "type_traits",
        "pointer_traits", "hash<", "equal_to<", "less<", "__tree",
        "__hash", "unary_function<", "binary_function<", "reference_wrapper<",
        "unique_ptr<", "shared_ptr<", "weak_ptr<", "auto_ptr<"
    ];
    for p in STL_PREFIXES {
        if s.contains(p) { return true; }
    }
    false
}

fn normalize_cxx_name(raw: &str) -> String {
    let mut s = raw.trim();
    if let Some(pos) = s.rfind("::") { s = &s[pos + 2..]; }
    s.to_string()
}

fn dwarf_namespace_of(cu_dies: &HashMap<usize, DieData>, die: &DieData) -> String {
    let mut parts: Vec<String> = Vec::new();
    let mut cur = die.parent;
    let mut guard = 0;
    while let Some(p) = cur {
        guard += 1;
        if guard > 128 { break; }
        match cu_dies.get(&p) {
            Some(pd) => {
                if matches!(pd.tag, 0x39 | 0x02 | 0x13 | 0x17) {
                    if let Some(ref n) = pd.name {
                        if !n.is_empty() { parts.push(n.clone()); }
                    }
                }
                cur = pd.parent;
            }
            None => break,
        }
    }
    parts.reverse();
    parts.join("::")
}

const WINDOWS_RESERVED_NAMES: &[&str] = &[
    "CON", "PRN", "AUX", "NUL",
    "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
    "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9",
];

fn class_file_base(qualified: &str) -> String {
    let mut s: String = qualified
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() || c == '_' { c } else { '_' })
        .collect();
    while s.contains("__") { s = s.replace("__", "_"); }
    let mut s = s.trim_matches('_').to_string();
    if s.is_empty() { s = "UnnamedClass".to_string(); }
    if s.chars().next().map_or(false, |c| c.is_ascii_digit()) { s.insert_str(0, "C_"); }
    if s.len() > 120 { s.truncate(120); }
    s
}

fn claim_unique_stem(base: &str, used_lower: &mut HashSet<String>) -> String {
    let mut candidate = base.to_string();
    if WINDOWS_RESERVED_NAMES.iter().any(|r| r.eq_ignore_ascii_case(&candidate)) {
        candidate.push('_');
    }
    let mut n = 2;
    while used_lower.contains(&candidate.to_ascii_lowercase()) {
        candidate = format!("{}_{}", base, n);
        n += 1;
    }
    used_lower.insert(candidate.to_ascii_lowercase());
    candidate
}

// ----------------------------------------------------------------------------
// LEB128 & Varint Readers
// ----------------------------------------------------------------------------

fn read_varint(data: &[u8], mut pos: usize) -> (u64, usize) {
    let mut res: u64 = 0;
    let mut shift = 0;
    while pos < data.len() {
        let b = data[pos];
        pos += 1;
        res |= ((b & 0x7F) as u64) << shift;
        if (b & 0x80) == 0 { break; }
        shift += 7;
    }
    (res, pos)
}

#[inline(always)]
fn read_uleb128(data: &[u8], pos: usize) -> (u64, usize) {
    read_varint(data, pos)
}

#[inline(always)]
fn read_sleb128(data: &[u8], mut pos: usize) -> (i64, usize) {
    let mut res: i64 = 0;
    let mut shift = 0;
    while pos < data.len() {
        let b = data[pos];
        pos += 1;
        res |= ((b & 0x7F) as i64) << shift;
        shift += 7;
        if (b & 0x80) == 0 {
            if shift < 64 && (b & 0x40) != 0 {
                res |= (!0i64) << shift;
            }
            break;
        }
    }
    (res, pos)
}

// ----------------------------------------------------------------------------
// 64-bit ELF Relocation & VTable Parser
// ----------------------------------------------------------------------------

pub fn is_flat_memory_dump(mmap: &[u8], e_phoff: usize, e_phentsize: usize, e_phnum: usize) -> bool {
    for i in 0..e_phnum {
        let hdr = e_phoff + i * e_phentsize;
        if hdr + 56 > mmap.len() { break; }
        let p_type = u32::from_le_bytes(mmap[hdr..hdr + 4].try_into().unwrap());
        if p_type == 2 { // PT_DYNAMIC
            let p_vaddr = u64::from_le_bytes(mmap[hdr + 16..hdr + 24].try_into().unwrap()) as usize;
            if p_vaddr + 16 <= mmap.len() {
                let tag = i64::from_le_bytes(mmap[p_vaddr..p_vaddr + 8].try_into().unwrap());
                if tag >= 1 && tag <= 38 {
                    return true;
                }
            }
        }
    }
    false
}

pub fn vaddr_to_file_offset(mmap: &[u8], e_phoff: usize, e_phentsize: usize, e_phnum: usize, vaddr: u64) -> Option<usize> {
    let v = vaddr as usize;
    if is_flat_memory_dump(mmap, e_phoff, e_phentsize, e_phnum) {
        return if v < mmap.len() { Some(v) } else { None };
    }
    for i in 0..e_phnum {
        let hdr = e_phoff + i * e_phentsize;
        if hdr + 56 > mmap.len() { break; }
        let p_type = u32::from_le_bytes(mmap[hdr..hdr + 4].try_into().unwrap());
        if p_type != 1 { continue; }
        let p_offset = u64::from_le_bytes(mmap[hdr + 8..hdr + 16].try_into().unwrap()) as usize;
        let p_vaddr = u64::from_le_bytes(mmap[hdr + 16..hdr + 24].try_into().unwrap()) as usize;
        let p_filesz = u64::from_le_bytes(mmap[hdr + 32..hdr + 40].try_into().unwrap()) as usize;
        if v >= p_vaddr && v < p_vaddr + p_filesz {
            let off = p_offset + (v - p_vaddr);
            return if off < mmap.len() { Some(off) } else { None };
        }
    }
    None
}

pub fn demangle_itanium_vtable(raw: &str) -> Option<String> {
    let mut s = raw.trim();
    if s.starts_with("_ZTV") || s.starts_with("_ZTI") || s.starts_with("_ZTS") {
        s = &s[4..];
    }
    if s.is_empty() { return None; }
    // Filter lambdas, closures, and internal runtime structures
    if s.contains("$_") || s.contains("__func") || s.contains("<lambda") 
        || s.contains("NSt6__ndk1") || s.contains("(anonymous") || s.contains("__cxxabiv1") {
        return None;
    }
    // Simple class: <length><name>
    if s.chars().next().map_or(false, |c| c.is_ascii_digit()) {
        let mut idx = 0;
        let bytes = s.as_bytes();
        while idx < bytes.len() && bytes[idx].is_ascii_digit() {
            idx += 1;
        }
        if let Ok(len) = s[..idx].parse::<usize>() {
            if idx + len == s.len() {
                return Some(s[idx..idx + len].to_string());
            }
        }
    }
    // Nested class / namespace: N<len1><part1><len2><part2>...E
    if s.starts_with('N') && s.ends_with('E') && s.len() >= 4 {
        let content = &s[1..s.len() - 1];
        let bytes = content.as_bytes();
        let mut parts = Vec::new();
        let mut idx = 0;
        let mut ok = true;
        while idx < bytes.len() {
            if !bytes[idx].is_ascii_digit() {
                ok = false;
                break;
            }
            let l_start = idx;
            while idx < bytes.len() && bytes[idx].is_ascii_digit() {
                idx += 1;
            }
            if let Ok(len) = content[l_start..idx].parse::<usize>() {
                if idx + len > bytes.len() {
                    ok = false;
                    break;
                }
                parts.push(content[idx..idx + len].to_string());
                idx += len;
            } else {
                ok = false;
                break;
            }
        }
        if ok && idx == bytes.len() && !parts.is_empty() {
            return Some(parts.join("::"));
        }
    }
    None
}

/// Extracts ground-truth primary VTables from ELF .symtab (if unstripped DWARF reference is provided).
pub fn extract_symtab_vtables(mmap: &[u8]) -> HashMap<String, (u64, usize)> {
    let mut vtables = HashMap::new();
    if mmap.len() < 64 || &mmap[0..4] != b"\x7fELF" { return vtables; }

    let e_shoff = u64::from_le_bytes(mmap[40..48].try_into().unwrap()) as usize;
    let e_shentsize = u16::from_le_bytes(mmap[58..60].try_into().unwrap()) as usize;
    let e_shnum = u16::from_le_bytes(mmap[60..62].try_into().unwrap()) as usize;
    let e_shstrndx = u16::from_le_bytes(mmap[62..64].try_into().unwrap()) as usize;

    if e_shoff == 0 || e_shentsize == 0 || e_shnum == 0 || e_shstrndx >= e_shnum {
        return vtables;
    }
    if e_shoff + e_shnum * e_shentsize > mmap.len() { return vtables; }

    let shstr_hdr = e_shoff + e_shstrndx * e_shentsize;
    let shstr_off = u64::from_le_bytes(mmap[shstr_hdr + 24..shstr_hdr + 32].try_into().unwrap()) as usize;
    let shstr_sz = u64::from_le_bytes(mmap[shstr_hdr + 32..shstr_hdr + 40].try_into().unwrap()) as usize;
    if shstr_off + shstr_sz > mmap.len() { return vtables; }

    let mut symtab_off = 0;
    let mut symtab_sz = 0;
    let mut strtab_off = 0;
    let mut _strtab_sz = 0;

    for i in 0..e_shnum {
        let sh = e_shoff + i * e_shentsize;
        let name_off = u32::from_le_bytes(mmap[sh..sh + 4].try_into().unwrap()) as usize;
        let sh_type = u32::from_le_bytes(mmap[sh + 4..sh + 8].try_into().unwrap());
        let sh_offset = u64::from_le_bytes(mmap[sh + 24..sh + 32].try_into().unwrap()) as usize;
        let sh_size = u64::from_le_bytes(mmap[sh + 32..sh + 40].try_into().unwrap()) as usize;

        if shstr_off + name_off < mmap.len() {
            let s_slice = &mmap[shstr_off + name_off..];
            let name_len = s_slice.iter().position(|&b| b == 0).unwrap_or(0);
            if let Ok(name) = std::str::from_utf8(&s_slice[..name_len]) {
                if name == ".symtab" && sh_type == 2 {
                    symtab_off = sh_offset;
                    symtab_sz = sh_size;
                } else if name == ".strtab" && sh_type == 3 {
                    strtab_off = sh_offset;
                    _strtab_sz = sh_size;
                }
            }
        }
    }

    if symtab_off == 0 || strtab_off == 0 || symtab_sz == 0 { return vtables; }

    let sym_count = symtab_sz / 24;
    for i in 0..sym_count {
        let soff = symtab_off + i * 24;
        if soff + 24 > mmap.len() { break; }
        let st_name = u32::from_le_bytes(mmap[soff..soff + 4].try_into().unwrap()) as usize;
        let st_value = u64::from_le_bytes(mmap[soff + 8..soff + 16].try_into().unwrap());
        let st_size = u64::from_le_bytes(mmap[soff + 16..soff + 24].try_into().unwrap());

        if st_name != 0 && strtab_off + st_name < mmap.len() {
            let str_slice = &mmap[strtab_off + st_name..];
            let end = str_slice.iter().position(|&b| b == 0).unwrap_or(0);
            if let Ok(sname) = std::str::from_utf8(&str_slice[..end]) {
                if sname.starts_with("_ZTV") {
                    if let Some(demangled) = demangle_itanium_vtable(sname) {
                        // In Itanium C++ ABI, the primary vtable slot 0 begins 16 bytes after symbol start
                        let primary_vtable = st_value + 16;
                        let vfunc_count = if st_size >= 16 { ((st_size - 16) / 8) as usize } else { 0 };
                        if vfunc_count >= 1 {
                            vtables.insert(demangled, (primary_vtable, vfunc_count));
                        }
                    }
                }
            }
        }
    }
    vtables
}

/// Extracts verified primary VTables from ELF dynamic relocations (DT_RELA / DT_RELR).
pub fn extract_rtti_vtables(mmap: &[u8]) -> HashMap<String, (u64, usize)> {
    let mut vtables = HashMap::new();
    if mmap.len() < 64 || &mmap[0..4] != b"\x7fELF" { return vtables; }

    let e_phoff = u64::from_le_bytes(mmap[32..40].try_into().unwrap()) as usize;
    let e_phentsize = u16::from_le_bytes(mmap[54..56].try_into().unwrap()) as usize;
    let e_phnum = u16::from_le_bytes(mmap[56..58].try_into().unwrap()) as usize;

    if e_phoff + e_phnum * e_phentsize > mmap.len() { return vtables; }

    let is_flat = is_flat_memory_dump(mmap, e_phoff, e_phentsize, e_phnum);

    let mut exec_ranges: Vec<(u64, u64)> = Vec::new();
    let mut dynamic_off = 0;
    let mut dynamic_sz = 0;

    for i in 0..e_phnum {
        let hdr = e_phoff + i * e_phentsize;
        let p_type = u32::from_le_bytes(mmap[hdr..hdr+4].try_into().unwrap());
        let p_flags = u32::from_le_bytes(mmap[hdr+4..hdr+8].try_into().unwrap());
        let p_offset = u64::from_le_bytes(mmap[hdr+8..hdr+16].try_into().unwrap());
        let p_vaddr = u64::from_le_bytes(mmap[hdr+16..hdr+24].try_into().unwrap());
        let p_filesz = u64::from_le_bytes(mmap[hdr+32..hdr+40].try_into().unwrap());
        let p_memsz = u64::from_le_bytes(mmap[hdr+40..hdr+48].try_into().unwrap());

        if p_type == 1 && (p_flags & 1) != 0 {
            exec_ranges.push((p_vaddr, p_vaddr.saturating_add(p_memsz)));
        } else if p_type == 2 {
            if is_flat {
                dynamic_off = p_vaddr as usize;
                dynamic_sz = p_memsz as usize;
            } else {
                dynamic_off = p_offset as usize;
                dynamic_sz = p_filesz as usize;
            }
        }
    }

    if dynamic_off == 0 || dynamic_off + dynamic_sz > mmap.len() { return vtables; }

    let mut dt_rela = None;
    let mut dt_relasz = None;
    let mut dt_symtab: Option<usize> = None;
    let mut dt_pltgot: Option<usize> = None;
    let mut dt_relr: Option<usize> = None;
    let mut dt_relrsz: Option<usize> = None;

    let mut i = 0;
    while i < dynamic_sz {
        let entry = dynamic_off + i;
        if entry + 16 > mmap.len() { break; }
        let d_tag = i64::from_le_bytes(mmap[entry..entry+8].try_into().unwrap());
        let d_val = u64::from_le_bytes(mmap[entry+8..entry+16].try_into().unwrap()) as usize;
        i += 16;
        if d_tag == 0 { break; }
        if d_tag == 3 { dt_pltgot = Some(d_val); }
        if d_tag == 6 { dt_symtab = Some(d_val); }
        if d_tag == 7 { dt_rela = Some(d_val); }
        if d_tag == 8 { dt_relasz = Some(d_val); }
        if d_tag == 35 { dt_relrsz = Some(d_val); }
        if d_tag == 36 { dt_relr = Some(d_val); }
    }

    let sym_file_off = dt_symtab.and_then(|v| vaddr_to_file_offset(mmap, e_phoff, e_phentsize, e_phnum, v as u64));
    let symbol_value = |idx: usize| -> Option<u64> {
        let off = sym_file_off? + idx * 24 + 8;
        if off + 8 > mmap.len() { return None; }
        Some(u64::from_le_bytes(mmap[off..off + 8].try_into().ok()?))
    };

    let mut rel_map: HashMap<u64, u64> = HashMap::new();

    if let (Some(r_v), Some(s)) = (dt_rela, dt_relasz) {
        if let Some(rela_off) = vaddr_to_file_offset(mmap, e_phoff, e_phentsize, e_phnum, r_v as u64) {
            let count = s / 24;
            for idx in 0..count {
                let entry_off = rela_off + idx * 24;
                if entry_off + 24 > mmap.len() { break; }
                let r_offset = u64::from_le_bytes(mmap[entry_off..entry_off+8].try_into().unwrap());
                let r_info = u64::from_le_bytes(mmap[entry_off+8..entry_off+16].try_into().unwrap());
                let r_addend = u64::from_le_bytes(mmap[entry_off+16..entry_off+24].try_into().unwrap());
                let r_type = (r_info & 0xFFFFFFFF) as u32;
                let sym_idx = (r_info >> 32) as usize;
                let target = if r_type == 1027 || r_type == 8 {
                    Some(r_addend)
                } else if (r_type == 257 || r_type == 1) && sym_idx != 0 {
                    symbol_value(sym_idx).filter(|&v| v != 0).map(|v| v.wrapping_add(r_addend))
                } else {
                    None
                };
                if let Some(t) = target {
                    rel_map.insert(r_offset, t);
                }
            }
        }
    }

    if let (Some(relr_v), Some(relr_sz)) = (dt_relr, dt_relrsz) {
        if let Some(relr_off) = vaddr_to_file_offset(mmap, e_phoff, e_phentsize, e_phnum, relr_v as u64) {
            let mut locs: Vec<u64> = Vec::new();
            let mut where_: u64 = 0;
            for k in 0..(relr_sz / 8) {
                let o = relr_off + k * 8;
                if o + 8 > mmap.len() { break; }
                let entry = u64::from_le_bytes(mmap[o..o + 8].try_into().unwrap());
                if entry & 1 == 0 {
                    where_ = entry;
                    locs.push(where_);
                    where_ += 8;
                } else {
                    let mut bits = entry >> 1;
                    let mut i: u64 = 0;
                    while bits != 0 {
                        if bits & 1 == 1 { locs.push(where_ + 8 * i); }
                        bits >>= 1;
                        i += 1;
                    }
                    where_ += 8 * 63;
                }
            }
            for loc in locs {
                if let Some(loff) = vaddr_to_file_offset(mmap, e_phoff, e_phentsize, e_phnum, loc) {
                    if loff + 8 <= mmap.len() {
                        let value = u64::from_le_bytes(mmap[loff..loff + 8].try_into().unwrap());
                        rel_map.insert(loc, value);
                    }
                }
            }
        }
    }

    let ph = (e_phoff, e_phentsize, e_phnum);

    // If memory dump, detect runtime memory base address (e.g. 0x7b06d8a000)
    let mut mem_load_base: u64 = 0;
    if is_flat {
        for (&r_offset, &target) in &rel_map {
            if let Some(off) = vaddr_to_file_offset(mmap, ph.0, ph.1, ph.2, r_offset) {
                if off + 8 <= mmap.len() {
                    let mem_val = u64::from_le_bytes(mmap[off..off + 8].try_into().unwrap());
                    if mem_val > target && mem_val >= 0x100000000 {
                        let cand_base = mem_val - target;
                        if cand_base >= 0x100000000 {
                            mem_load_base = cand_base;
                            break;
                        }
                    }
                }
            }
        }
    }

    let normalize_ptr = |ptr: u64| -> u64 {
        if mem_load_base != 0 && ptr >= mem_load_base {
            ptr - mem_load_base
        } else if ptr >= 0x7b00000000 {
            ptr & 0xFFFFFFFF
        } else {
            ptr
        }
    };

    let is_exec = |v: u64| -> bool {
        let norm_v = normalize_ptr(v);
        exec_ranges.iter().any(|&(s, e)| norm_v >= s && norm_v < e)
    };

    let mut rtti_map: HashMap<u64, String> = HashMap::new();
    for (&_r_offset, &t_addr) in &rel_map {
        let t_off = match vaddr_to_file_offset(mmap, ph.0, ph.1, ph.2, t_addr) {
            Some(o) => o,
            None => continue,
        };
        if t_off + 16 <= mmap.len() {
            let mut name_ptr = rel_map.get(&(t_addr + 8)).copied().unwrap_or_else(|| {
                u64::from_le_bytes(mmap[t_off + 8..t_off + 16].try_into().unwrap())
            });
            name_ptr = normalize_ptr(name_ptr);
            let n_off = match vaddr_to_file_offset(mmap, ph.0, ph.1, ph.2, name_ptr) {
                Some(o) => o,
                None => continue,
            };
            if n_off > 0 && n_off < mmap.len() {
                if let Some(end) = mmap[n_off..].iter().position(|&b| b == 0) {
                    if end > 0 && end < 256 {
                        if let Ok(raw_str) = std::str::from_utf8(&mmap[n_off..n_off + end]) {
                            if let Some(demangled) = demangle_itanium_vtable(raw_str) {
                                rtti_map.insert(t_addr, demangled);
                            }
                        }
                    }
                }
            }
        }
    }

    let got_boundary = dt_pltgot.map(|g| g as u64).unwrap_or(u64::MAX);

    for (&r_offset, &t_addr) in &rel_map {
        let clean_name = match rtti_map.get(&t_addr) {
            Some(n) => n,
            None => continue,
        };
        // Exclude Global Offset Table (.got) slots
        if r_offset >= got_boundary { continue; }

        let vtable_addr = r_offset + 8;
        // Check offset_to_top at vtable_addr - 16
        let ott_off = match vaddr_to_file_offset(mmap, ph.0, ph.1, ph.2, vtable_addr.saturating_sub(16)) {
            Some(o) => o,
            None => continue,
        };
        if ott_off + 8 > mmap.len() { continue; }
        let offset_to_top = i64::from_le_bytes(mmap[ott_off..ott_off + 8].try_into().unwrap());
        if offset_to_top != 0 { continue; } // Strict primary VTable verification!

        // Check slot 0 points to executable code
        let slot0 = rel_map.get(&vtable_addr).copied().unwrap_or_else(|| {
            vaddr_to_file_offset(mmap, ph.0, ph.1, ph.2, vtable_addr)
                .and_then(|o| if o + 8 <= mmap.len() {
                    let raw_val = u64::from_le_bytes(mmap[o..o+8].try_into().unwrap());
                    Some(normalize_ptr(raw_val))
                } else { None })
                .unwrap_or(0)
        });
        if !is_exec(slot0) { continue; }

        // Count consecutive executable slots
        let mut func_count = 0;
        let mut idx = 0;
        loop {
            let slot = vtable_addr + idx * 8;
            let target = rel_map.get(&slot).copied().unwrap_or_else(|| {
                vaddr_to_file_offset(mmap, ph.0, ph.1, ph.2, slot)
                    .and_then(|o| if o + 8 <= mmap.len() {
                        let raw_val = u64::from_le_bytes(mmap[o..o+8].try_into().unwrap());
                        Some(normalize_ptr(raw_val))
                    } else { None })
                    .unwrap_or(0)
            });
            if !is_exec(target) { break; }
            func_count += 1;
            idx += 1;
        }

        if func_count == 0 { continue; }

        let better = match vtables.get(clean_name) {
            Some(&(addr, n)) => func_count > n || (func_count == n && vtable_addr < addr),
            None => true,
        };
        if better {
            vtables.insert(clean_name.clone(), (vtable_addr, func_count));
        }
    }

    vtables
}

/// Final comprehensive VTable verification & resolution pass.
/// Runs *at last* after all schema elements (DWARF, Protobuf, ARM64 assembly) are dumped.
pub fn finalize_and_verify_vtables(
    classes: &mut HashMap<String, ClassEntry>,
    rel_mmap: &Mmap,
    dwarf_mmap_opt: Option<&Mmap>,
) {
    println!("[*] Starting Final VTable Verification & Resolution Pass (\"find them at last\")...");

    // Step 1: Pre-clear ALL existing vtables so only verified primary vtables survive
    for centry in classes.values_mut() {
        centry.vtable = None;
        centry.virtual_function_count = None;
    }

    // Step 2: Recover verified primary RTTI VTables from the release target library
    let mut unified_vtables: HashMap<String, (u64, usize)> = extract_rtti_vtables(rel_mmap);
    println!("    [*] Recovered {} verified primary RTTI VTables from target release binary.", unified_vtables.len());

    // Step 3: If target binary had no RTTI or if running DWARF-only mode, fall back to DWARF ground truth
    if unified_vtables.is_empty() {
        if let Some(dwarf_mmap) = dwarf_mmap_opt {
            let sym_vtables = extract_symtab_vtables(dwarf_mmap);
            println!("    [*] Recovered {} ground-truth _ZTV symbols from DWARF .symtab fallback.", sym_vtables.len());
            let dwarf_rtti = extract_rtti_vtables(dwarf_mmap);
            unified_vtables = dwarf_rtti;
            for (k, v) in sym_vtables {
                unified_vtables.insert(k, v);
            }
        }
    }

    println!("    [*] Unified {} candidate primary VTables for matching.", unified_vtables.len());

    // Step 4: Index classes by qualified and normalized names
    let mut qualified_map: HashMap<String, String> = HashMap::new();
    let mut norm_map: HashMap<String, Vec<String>> = HashMap::new();
    for key in classes.keys() {
        qualified_map.insert(key.clone(), key.clone());
        norm_map.entry(normalize_cxx_name(key)).or_default().push(key.clone());
    }

    // Step 5: Reconcile and assign verified VTables
    let mut assigned_count = 0;
    let mut new_vtable_classes = 0;

    for (cand_name, &(vt_addr, func_count)) in &unified_vtables {
        if func_count == 0 { continue; }

        let target_keys = if let Some(exact_key) = qualified_map.get(cand_name) {
            vec![exact_key.clone()]
        } else if let Some(matching_keys) = norm_map.get(&normalize_cxx_name(cand_name)) {
            if matching_keys.len() == 1 {
                matching_keys.clone()
            } else {
                let cand_norm = normalize_cxx_name(cand_name);
                let exact_simple = matching_keys.iter().find(|k| **k == cand_norm);
                if let Some(s) = exact_simple {
                    vec![s.clone()]
                } else {
                    matching_keys.clone()
                }
            }
        } else {
            vec![cand_name.clone()]
        };

        for tkey in target_keys {
            let centry = classes.entry(tkey.clone()).or_insert_with(|| {
                new_vtable_classes += 1;
                let mut e = ClassEntry::code_only();
                if let Some(pos) = cand_name.rfind("::") {
                    e.namespace = Some(cand_name[..pos].to_string());
                }
                e
            });

            centry.vtable = Some(format!("0x{:X}", vt_addr));
            centry.virtual_function_count = Some(func_count);
            assigned_count += 1;
        }
    }

    // Step 6: Final sweep - guarantee non-virtual classes remain without vtables
    for centry in classes.values_mut() {
        if let Some(ref vt_str) = centry.vtable {
            let vfc = centry.virtual_function_count.unwrap_or(0);
            if vfc == 0 || vt_str.is_empty() {
                centry.vtable = None;
                centry.virtual_function_count = None;
            }
        }
    }

    println!("[+] Successfully verified and reconciled {} primary VTables ({} vtable-only classes added).", assigned_count, new_vtable_classes);
}

/// Backwards compatibility wrapper delegating to finalize_and_verify_vtables
pub fn parse_elf_vtables(mmap: &Mmap, classes: &mut HashMap<String, ClassEntry>) {
    finalize_and_verify_vtables(classes, mmap, None);
}


// ----------------------------------------------------------------------------
// Phase 1: Pure DWARF AST State Machine Parser (Supreme Ground Truth)
// ----------------------------------------------------------------------------

fn parse_dwarf_location_expr(raw_block: &[u8]) -> Option<u64> {
    if raw_block.is_empty() { return None; }
    let op = raw_block[0];
    match op {
        0x23 => { let (uval, _) = read_uleb128(raw_block, 1); Some(uval) }
        0x08 => { if raw_block.len() > 1 { Some(raw_block[1] as u64) } else { None } }
        0x09 => { if raw_block.len() > 1 { Some(raw_block[1] as i8 as u64) } else { None } }
        0x0a => { if raw_block.len() >= 3 { Some(u16::from_le_bytes(raw_block[1..3].try_into().unwrap()) as u64) } else { None } }
        0x0b => { if raw_block.len() >= 3 { Some(i16::from_le_bytes(raw_block[1..3].try_into().unwrap()) as u64) } else { None } }
        0x0c => { if raw_block.len() >= 5 { Some(u32::from_le_bytes(raw_block[1..5].try_into().unwrap()) as u64) } else { None } }
        0x0d => { if raw_block.len() >= 5 { Some(i32::from_le_bytes(raw_block[1..5].try_into().unwrap()) as u64) } else { None } }
        0x0e => { if raw_block.len() >= 9 { Some(u64::from_le_bytes(raw_block[1..9].try_into().unwrap())) } else { None } }
        0x0f => { if raw_block.len() >= 9 { Some(i64::from_le_bytes(raw_block[1..9].try_into().unwrap()) as u64) } else { None } }
        0x10 => { let (uval, _) = read_uleb128(raw_block, 1); Some(uval) }
        0x11 => { let (sval, _) = read_sleb128(raw_block, 1); Some(sval as u64) }
        0x30..=0x4f => Some((op - 0x30) as u64),
        _ => {
            if raw_block.len() == 1 { Some(raw_block[0] as u64) }
            else if raw_block.len() == 2 { Some(u16::from_le_bytes(raw_block[0..2].try_into().unwrap()) as u64) }
            else if raw_block.len() == 4 { Some(u32::from_le_bytes(raw_block[0..4].try_into().unwrap()) as u64) }
            else { None }
        }
    }
}

#[derive(Default, Clone)]
struct DieData {
    tag: u64,
    name: Option<String>,
    byte_size: Option<u64>,
    loc: Option<u64>,
    type_ref: Option<usize>,
    const_val: Option<i64>,
    is_external: bool,
    is_declaration: bool,
    children: Vec<usize>,
    parent: Option<usize>,
    access: Option<u64>,
}

fn resolve_dwarf_type(cu_dies: &HashMap<usize, DieData>, mut ref_off: usize) -> String {
    let mut ptr_depth = 0;
    let mut depth = 0;
    while depth < 8 && ref_off != 0 {
        depth += 1;
        match cu_dies.get(&ref_off) {
            Some(d) => {
                let t = d.tag;
                if t == 0x0F || t == 0x10 || t == 0x42 {
                    ptr_depth += 1;
                    if let Some(next_ref) = d.type_ref { ref_off = next_ref; continue; } else { break; }
                } else if t == 0x16 || t == 0x26 || t == 0x35 || t == 0x37 {
                    if let Some(next_ref) = d.type_ref { ref_off = next_ref; continue; } else {
                        let mut base = d.name.clone().unwrap_or_else(|| "void".to_string());
                        for _ in 0..ptr_depth { base.push('*'); }
                        return base;
                    }
                } else if t == 0x24 {
                    let mut base = d.name.clone().unwrap_or_else(|| "void".to_string());
                    for _ in 0..ptr_depth { base.push('*'); }
                    return base;
                } else if t == 0x13 || t == 0x02 || t == 0x17 {
                    let mut base = d.name.clone().unwrap_or_else(|| "struct".to_string());
                    for _ in 0..ptr_depth { base.push('*'); }
                    return base;
                } else if t == 0x04 {
                    let mut base = d.name.clone().unwrap_or_else(|| "int".to_string());
                    for _ in 0..ptr_depth { base.push('*'); }
                    return base;
                } else if let Some(ref nm) = d.name {
                    let mut base = nm.clone();
                    for _ in 0..ptr_depth { base.push('*'); }
                    return base;
                } else { break; }
            }
            None => break,
        }
    }
    let mut base = "void".to_string();
    for _ in 0..ptr_depth { base.push('*'); }
    base
}

fn collect_struct_fields(
    cu_dies: &HashMap<usize, DieData>,
    die: &DieData,
    base_offset: u64,
    f_dict: &mut BTreeMap<String, FieldInfo>,
    seen_fn: &mut HashMap<String, usize>,
    visited: &mut HashSet<usize>,
) {
    let default_access = if die.tag == 0x02 { 3u64 } else { 1u64 };

    for &ch_off in &die.children {
        if !visited.insert(ch_off) { continue; }
        if let Some(ch) = cu_dies.get(&ch_off) {
            if ch.tag == 0x1C { // DW_TAG_inheritance (Base Class)
                let inherited_offset = base_offset + ch.loc.unwrap_or(0);
                if let Some(base_type_ref) = ch.type_ref {
                    if let Some(base_die) = cu_dies.get(&base_type_ref) {
                        collect_struct_fields(cu_dies, base_die, inherited_offset, f_dict, seen_fn, visited);
                    }
                }
            } else if ch.tag == 0x0D { // DW_TAG_member
                if ch.is_declaration { continue; }
                let fo = ch.loc.unwrap_or(0);
                let total_off = base_offset + fo;
                let access = access_keyword(ch.access.unwrap_or(default_access)).map(|s| s.to_string());

                match ch.name {
                    Some(ref fn_name) => {
                        let raw_t = ch.type_ref.map(|tr| resolve_dwarf_type(cu_dies, tr)).unwrap_or_else(|| "void".to_string());
                        let cs_t = simplify_type(&raw_t);
                        let mut clean_f = sanitize_fname(fn_name);
                        let count = seen_fn.entry(clean_f.clone()).or_insert(0);
                        *count += 1;
                        if *count > 1 { clean_f = format!("{}_{}", clean_f, count); }
                        f_dict.insert(clean_f, FieldInfo {
                            offset: format!("0x{:X}", total_off),
                            field_type: cs_t,
                            access,
                        });
                    }
                    None => {
                        if let Some(tr) = ch.type_ref {
                            if let Some(anon) = cu_dies.get(&tr) {
                                if matches!(anon.tag, 0x02 | 0x13 | 0x17) {
                                    collect_struct_fields(cu_dies, anon, total_off, f_dict, seen_fn, visited);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

pub fn parse_dwarf_ast(mmap: &Mmap, classes: &mut HashMap<String, ClassEntry>, enums: &mut HashMap<String, EnumEntry>) {
    let t0 = Instant::now();
    println!("[*] Parsing DWARF Debug Sections (.debug_info, .debug_abbrev, .debug_str)...");

    if mmap.len() < 64 || &mmap[0..4] != b"\x7fELF" {
        println!("[!] Not an ELF binary.");
        return;
    }

    let e_shoff = u64::from_le_bytes(mmap[40..48].try_into().unwrap()) as usize;
    let e_shentsize = u16::from_le_bytes(mmap[58..60].try_into().unwrap()) as usize;
    let e_shnum = u16::from_le_bytes(mmap[60..62].try_into().unwrap()) as usize;
    let e_shstrndx = u16::from_le_bytes(mmap[62..64].try_into().unwrap()) as usize;

    if e_shoff == 0 || e_shoff + e_shnum * e_shentsize > mmap.len() || e_shstrndx >= e_shnum {
        println!("[!] Section header table is truncated or invalid.");
        return;
    }
    let shstr_hdr = e_shoff + e_shstrndx * e_shentsize;
    let shstr_off = u64::from_le_bytes(mmap[shstr_hdr + 24..shstr_hdr + 32].try_into().unwrap()) as usize;

    let mut sections = HashMap::new();
    let mut compressed_sections: HashSet<String> = HashSet::new();
    for i in 0..e_shnum {
        let hdr = e_shoff + i * e_shentsize;
        let name_idx = u32::from_le_bytes(mmap[hdr..hdr + 4].try_into().unwrap()) as usize;
        let s_flags = u64::from_le_bytes(mmap[hdr + 8..hdr + 16].try_into().unwrap());
        let s_off = u64::from_le_bytes(mmap[hdr + 24..hdr + 32].try_into().unwrap()) as usize;
        let s_sz = u64::from_le_bytes(mmap[hdr + 32..hdr + 40].try_into().unwrap()) as usize;
        let str_start = shstr_off + name_idx;
        if str_start < mmap.len() {
            if let Some(end) = mmap[str_start..].iter().position(|&b| b == 0) {
                if let Ok(s_name) = std::str::from_utf8(&mmap[str_start..str_start + end]) {
                    if s_flags & 0x800 != 0 {
                        compressed_sections.insert(s_name.to_string());
                    }
                    sections.insert(s_name.to_string(), (s_off, s_sz));
                }
            }
        }
    }

    let (info_off, info_sz) = match sections.get(".debug_info") {
        Some(&v) => v,
        None => { println!("[!] .debug_info section not found."); return; }
    };
    if compressed_sections.contains(".debug_info") {
        println!("[!] .debug_info is compressed.");
        return;
    }
    let (abbrev_off, abbrev_sz) = match sections.get(".debug_abbrev") {
        Some(&v) => v,
        None => return,
    };
    let (str_off, str_sz) = match sections.get(".debug_str") {
        Some(&v) => v,
        None => return,
    };

    let fits = |off: usize, sz: usize| off.checked_add(sz).map_or(false, |end| end <= mmap.len());
    if !fits(info_off, info_sz) || !fits(abbrev_off, abbrev_sz) || !fits(str_off, str_sz) {
        println!("[!] DWARF sections extend past the end of the file.");
        return;
    }
    let info_bytes = &mmap[info_off..info_off + info_sz];
    let abbrev_bytes = &mmap[abbrev_off..abbrev_off + abbrev_sz];
    let str_bytes = &mmap[str_off..str_off + str_sz];

    let get_str = |offset: usize| -> String {
        if offset >= str_bytes.len() { return String::new(); }
        match str_bytes[offset..].iter().position(|&b| b == 0) {
            Some(end) => std::str::from_utf8(&str_bytes[offset..offset + end]).unwrap_or("").to_string(),
            None => String::new(),
        }
    };

    type AbbrevTable = HashMap<u64, (u64, bool, Vec<(u64, u64, i64)>)>;

    let parse_abbrevs = |mut off: usize| -> AbbrevTable {
        let mut table: AbbrevTable = HashMap::new();
        while off < abbrev_bytes.len() {
            let (code, next) = read_uleb128(abbrev_bytes, off);
            off = next;
            if code == 0 { break; }
            let (tag, next) = read_uleb128(abbrev_bytes, off);
            off = next;
            let has_ch = abbrev_bytes[off] != 0;
            off += 1;
            let mut attrs = Vec::new();
            loop {
                let (aname, next) = read_uleb128(abbrev_bytes, off);
                off = next;
                let (aform, next) = read_uleb128(abbrev_bytes, off);
                off = next;
                if aname == 0 && aform == 0 { break; }
                let mut iconst = 0i64;
                if aform == 0x21 {
                    let (v, next) = read_sleb128(abbrev_bytes, off);
                    off = next;
                    iconst = v;
                }
                attrs.push((aname, aform, iconst));
            }
            table.insert(code, (tag, has_ch, attrs));
        }
        table
    };

    let mut abbrev_cache: HashMap<usize, AbbrevTable> = HashMap::new();
    let mut cu_pos = 0;

    while cu_pos < info_sz {
        if cu_pos + 12 > info_sz { break; }
        let ulen = u32::from_le_bytes(info_bytes[cu_pos..cu_pos + 4].try_into().unwrap()) as usize;
        if ulen == 0 { break; }
        let cu_end = (cu_pos + 4 + ulen).min(info_sz);
        let version = u16::from_le_bytes(info_bytes[cu_pos + 4..cu_pos + 6].try_into().unwrap());
        let (ab_off, header_len) = if version >= 5 {
            let unit_type = info_bytes[cu_pos + 6];
            let ab = u32::from_le_bytes(info_bytes[cu_pos + 8..cu_pos + 12].try_into().unwrap()) as usize;
            let extra = match unit_type { 0x02 | 0x06 => 12, 0x04 | 0x05 => 8, _ => 0 };
            (ab, 12 + extra)
        } else {
            let ab = u32::from_le_bytes(info_bytes[cu_pos + 6..cu_pos + 10].try_into().unwrap()) as usize;
            (ab, 11)
        };
        let abbrevs = abbrev_cache.entry(ab_off).or_insert_with(|| parse_abbrevs(ab_off));

        let mut pos = cu_pos + header_len;
        let mut cu_dies: HashMap<usize, DieData> = HashMap::new();
        let mut stack: Vec<usize> = Vec::new();

        while pos < cu_end {
            let die_off = pos;
            let (code, next) = read_uleb128(info_bytes, pos);
            pos = next;
            if code == 0 {
                stack.pop();
                continue;
            }

            let (tag, has_ch, attrs) = match abbrevs.get(&code) {
                Some(v) => v.clone(),
                None => break,
            };

            let mut die = DieData { tag, ..Default::default() };
            if let Some(&parent_off) = stack.last() {
                die.parent = Some(parent_off);
                if let Some(parent) = cu_dies.get_mut(&parent_off) {
                    parent.children.push(die_off);
                }
            }

            for &(aname, aform, iconst) in &attrs {
                let mut val_num: Option<u64> = None;
                let mut val_snum: Option<i64> = None;
                let mut val_str: Option<String> = None;
                let mut loc_block: Option<Vec<u8>> = None;

                match aform {
                    0x0b | 0x0c => {
                        if pos < info_bytes.len() {
                            let b = info_bytes[pos];
                            pos += 1;
                            val_num = Some(b as u64);
                            val_snum = Some(b as i64);
                        }
                    }
                    0x05 => {
                        if pos + 2 <= info_bytes.len() {
                            let v = u16::from_le_bytes(info_bytes[pos..pos + 2].try_into().unwrap());
                            pos += 2;
                            val_num = Some(v as u64);
                            val_snum = Some(v as i64);
                        }
                    }
                    0x06 | 0x10 => {
                        if pos + 4 <= info_bytes.len() {
                            let v = u32::from_le_bytes(info_bytes[pos..pos + 4].try_into().unwrap());
                            pos += 4;
                            val_num = Some(v as u64);
                            val_snum = Some(v as i64);
                        }
                    }
                    0x0e => {
                        if pos + 4 <= info_bytes.len() {
                            let off = u32::from_le_bytes(info_bytes[pos..pos + 4].try_into().unwrap()) as usize;
                            pos += 4;
                            val_str = Some(get_str(off));
                        }
                    }
                    0x13 => {
                        if pos + 4 <= info_bytes.len() {
                            let off = u32::from_le_bytes(info_bytes[pos..pos + 4].try_into().unwrap()) as usize;
                            pos += 4;
                            val_num = Some((cu_pos + off) as u64);
                        }
                    }
                    0x17 => {
                        if pos + 4 <= info_bytes.len() {
                            let v = u32::from_le_bytes(info_bytes[pos..pos + 4].try_into().unwrap());
                            pos += 4;
                            val_num = Some(v as u64);
                        }
                    }
                    0x01 | 0x07 => {
                        if pos + 8 <= info_bytes.len() {
                            let v = u64::from_le_bytes(info_bytes[pos..pos + 8].try_into().unwrap());
                            pos += 8;
                            val_num = Some(v);
                        }
                    }
                    0x14 => {
                        if pos + 8 <= info_bytes.len() {
                            let off = u64::from_le_bytes(info_bytes[pos..pos + 8].try_into().unwrap()) as usize;
                            pos += 8;
                            val_num = Some((cu_pos + off) as u64);
                        }
                    }
                    0x0d => {
                        let (sval, next) = read_sleb128(info_bytes, pos);
                        pos = next;
                        val_snum = Some(sval);
                        if sval >= 0 { val_num = Some(sval as u64); }
                    }
                    0x0f => {
                        let (uval, next) = read_uleb128(info_bytes, pos);
                        pos = next;
                        val_num = Some(uval);
                        val_snum = Some(uval as i64);
                    }
                    0x15 => {
                        let (uval, next) = read_uleb128(info_bytes, pos);
                        pos = next;
                        val_num = Some((cu_pos as u64) + uval);
                    }
                    0x08 => {
                        if let Some(end) = info_bytes[pos..].iter().position(|&b| b == 0) {
                            val_str = Some(std::str::from_utf8(&info_bytes[pos..pos + end]).unwrap_or("").to_string());
                            pos += end + 1;
                        } else { pos += 1; }
                    }
                    0x0a => {
                        if pos < info_bytes.len() {
                            let blen = info_bytes[pos] as usize;
                            pos += 1;
                            if pos + blen <= info_bytes.len() {
                                loc_block = Some(info_bytes[pos..pos + blen].to_vec());
                                pos += blen;
                            }
                        }
                    }
                    0x03 => {
                        if pos + 2 <= info_bytes.len() {
                            let blen = u16::from_le_bytes(info_bytes[pos..pos + 2].try_into().unwrap()) as usize;
                            pos += 2;
                            if pos + blen <= info_bytes.len() {
                                loc_block = Some(info_bytes[pos..pos + blen].to_vec());
                                pos += blen;
                            }
                        }
                    }
                    0x04 => {
                        if pos + 4 <= info_bytes.len() {
                            let blen = u32::from_le_bytes(info_bytes[pos..pos + 4].try_into().unwrap()) as usize;
                            pos += 4;
                            if pos + blen <= info_bytes.len() {
                                loc_block = Some(info_bytes[pos..pos + blen].to_vec());
                                pos += blen;
                            }
                        }
                    }
                    0x09 | 0x18 => {
                        let (blen, next) = read_uleb128(info_bytes, pos);
                        pos = next;
                        let blen = blen as usize;
                        if pos + blen <= info_bytes.len() {
                            loc_block = Some(info_bytes[pos..pos + blen].to_vec());
                            pos += blen;
                        }
                    }
                    0x19 => { val_num = Some(1); }
                    0x21 => {
                        val_num = Some(iconst as u64);
                        val_snum = Some(iconst);
                    }
                    0x11 => {
                        if pos < info_bytes.len() {
                            let v = info_bytes[pos];
                            pos += 1;
                            val_num = Some((cu_pos + v as usize) as u64);
                        }
                    }
                    0x12 => {
                        if pos + 2 <= info_bytes.len() {
                            let v = u16::from_le_bytes(info_bytes[pos..pos + 2].try_into().unwrap());
                            pos += 2;
                            val_num = Some((cu_pos + v as usize) as u64);
                        }
                    }
                    0x1a | 0x1b | 0x22 | 0x23 => { let (_v, next) = read_uleb128(info_bytes, pos); pos = next; }
                    0x25 | 0x29 => { pos += 1; }
                    0x26 | 0x2a => { pos += 2; }
                    0x27 | 0x2b => { pos += 3; }
                    0x28 | 0x2c => { pos += 4; }
                    0x1c | 0x1d | 0x1f => { pos += 4; }
                    0x20 => { pos += 8; }
                    0x1e => { pos += 16; }
                    _ => { pos += 1; }
                }

                match aname {
                    0x03 => { if let Some(s) = val_str { die.name = Some(s); } }
                    0x0B => { if let Some(v) = val_num { die.byte_size = Some(v); } }
                    0x38 => {
                        if let Some(ref block) = loc_block {
                            if let Some(parsed_loc) = parse_dwarf_location_expr(block) {
                                die.loc = Some(parsed_loc);
                            }
                        } else if let Some(v) = val_num {
                            die.loc = Some(v);
                        }
                    }
                    0x49 => { if let Some(v) = val_num { die.type_ref = Some(v as usize); } }
                    0x1C => {
                        if let Some(v) = val_snum { die.const_val = Some(v); }
                        else if let Some(v) = val_num { die.const_val = Some(v as i64); }
                    }
                    0x3F => { die.is_external = true; }
                    0x3C => { die.is_declaration = true; }
                    0x32 => { if let Some(v) = val_num { die.access = Some(v); } }
                    _ => {}
                }
            }

            cu_dies.insert(die_off, die);
            if has_ch { stack.push(die_off); }
        }

        // Extract ALL 10,058+ structures, classes, and enums (including 0-field virtual base classes)
        for die in cu_dies.values() {
            if matches!(die.tag, 0x02 | 0x13 | 0x17) {
                if let Some(ref sname) = die.name {
                    if is_stl_junk(sname) { continue; }
                    let ns = dwarf_namespace_of(&cu_dies, die);
                    let key = if ns.is_empty() { sname.clone() } else { format!("{}::{}", ns, sname) };

                    let mut f_dict = BTreeMap::new();
                    let mut seen_fn: HashMap<String, usize> = HashMap::new();
                    let mut visited = HashSet::new();

                    collect_struct_fields(&cu_dies, die, 0, &mut f_dict, &mut seen_fn, &mut visited);

                    let kind = match die.tag { 0x02 => "class", 0x17 => "union", _ => "struct" };
                    let nested_in_class = die.parent.and_then(|p| cu_dies.get(&p)).map_or(false, |p| p.tag == 0x02);
                    let default_acc = if nested_in_class { "private" } else { "public" };
                    let access = die.access.and_then(access_keyword).unwrap_or(default_acc).to_string();

                    let entry = ClassEntry {
                        vtable: None,
                        sizeof: die.byte_size.map(|sz| format!("0x{:X}", sz)),
                        virtual_function_count: None,
                        fields: f_dict,
                        kind: Some(kind.to_string()),
                        namespace: if ns.is_empty() { None } else { Some(ns.clone()) },
                        access: Some(access),
                    };

                    let should_insert = match classes.get(&key) {
                        Some(existing) => entry.fields.len() >= existing.fields.len(),
                        None => true,
                    };
                    if should_insert {
                        classes.insert(key, entry);
                    }
                }
            } else if die.tag == 0x04 { // DW_TAG_enumeration_type
                if let Some(ref ename) = die.name {
                    let ns = dwarf_namespace_of(&cu_dies, die);
                    let ekey = if ns.is_empty() { ename.clone() } else { format!("{}::{}", ns, ename) };
                    if !is_stl_junk(ename) && !enums.contains_key(&ekey) {
                        let mut evals = Vec::new();
                        let mut seen_ev = HashSet::new();
                        for &ch_off in &die.children {
                            if let Some(ch) = cu_dies.get(&ch_off) {
                                if ch.tag == 0x28 {
                                    if let Some(ref en) = ch.name {
                                        let ev = ch.const_val.unwrap_or(0);
                                        if seen_ev.insert(en.clone()) {
                                            evals.push((en.clone(), ev));
                                        }
                                    }
                                }
                            }
                        }
                        if !evals.is_empty() { enums.insert(ekey.clone(), EnumEntry { name: ekey.clone(), values: evals }); }
                    }
                }
            }
        }

        cu_pos = cu_end;
    }

    println!("[*] Extracted {} classes and {} enums from DWARF AST ({:.1}s).", classes.len(), enums.len(), t0.elapsed().as_secs_f32());
}

// ----------------------------------------------------------------------------
// Phase 2: Function-Scope Context-Tracking ARM64 Machine Code Offset Scanner
// ----------------------------------------------------------------------------

fn get_type_byte_size(type_str: &str) -> usize {
    let t = type_str.trim();
    if t.is_empty() { return 4; }
    // Pointer and IntPtr types are ALWAYS 8 bytes on 64-bit architectures
    if t.ends_with('*') || t == "IntPtr" {
        return 8;
    }
    if t.contains("::allocator") {
        if t.starts_with("vector<") || t.starts_with("std::vector<") { return 24; }
        if t.starts_with("shared_ptr<") || t.starts_with("std::shared_ptr<") { return 16; }
        if t.starts_with("unique_ptr<") || t.starts_with("std::unique_ptr<") { return 8; }
        if t.starts_with("string") || t.starts_with("std::string") { return 24; }
        return 8;
    }
    if t.starts_with("vector<") || t.starts_with("std::vector<") || t.starts_with("vector") { return 24; }
    if t.starts_with("string") || t.starts_with("std::string") { return 24; }
    if t.starts_with("shared_ptr<") || t.starts_with("std::shared_ptr<") { return 16; }
    if t.starts_with("unique_ptr<") || t.starts_with("std::unique_ptr<") { return 8; }
    if matches!(t, "bool" | "byte" | "int8" | "uint8" | "int8_t" | "uint8_t") { return 1; }
    if matches!(t, "short" | "ushort" | "int16" | "uint16" | "int16_t" | "uint16_t") { return 2; }
    if matches!(t, "int" | "uint" | "float" | "int32" | "uint32" | "int32_t" | "uint32_t") { return 4; }
    if matches!(t, "double" | "long" | "ulong" | "int64" | "uint64" | "int64_t" | "uint64_t") { return 8; }
    if matches!(t, "b2Vec2" | "Vec2" | "cocos2d::Vec2") { return 8; }
    if matches!(t, "Vec3" | "cocos2d::Vec3") { return 12; }
    4
}

fn scan_arm64_instructions(data: &[u8], classes: &mut HashMap<String, ClassEntry>) {
    // 1. Snapshot original baseline DWARF offsets for delta-shift calculations
    let mut original_dwarf_offsets: HashMap<String, HashMap<String, usize>> = HashMap::new();
    for (cname, centry) in classes.iter() {
        let mut fmap = HashMap::new();
        for (fname, finfo) in &centry.fields {
            if let Ok(off) = usize::from_str_radix(finfo.offset.trim_start_matches("0x"), 16) {
                fmap.insert(fname.clone(), off);
            }
        }
        original_dwarf_offsets.insert(cname.clone(), fmap);
    }

    // 2. Inverted index: field_name -> Vec<class_name>
    let mut field_to_classes: HashMap<String, Vec<String>> = HashMap::new();
    for (cname, centry) in classes.iter() {
        for fname in centry.fields.keys() {
            field_to_classes.entry(fname.clone()).or_default().push(cname.clone());
        }
    }

    let end_pos = data.len().min(0x1480000).saturating_sub(8);
    let mut pos = 0x1400000.min(data.len());
    let mut added_count = 0;
    let mut active_function_class: Option<String> = None;
    let mut scanned_class_fields: HashMap<String, HashSet<String>> = HashMap::new();

    while pos < end_pos {
        let insn1 = u32::from_le_bytes(data[pos..pos+4].try_into().unwrap());

        // Function Scope Boundary Reset:
        // Reset active function scope when hitting RET (0xD65F03C0),
        // function prologue STP X29, X30 (0xA98003E0 mask or 0xA9BF7BFD), or NOP padding (0xD503201F)
        if insn1 == 0xD65F03C0
            || (insn1 & 0xFFC003E0) == 0xA98003E0
            || insn1 == 0xA9BF7BFD
            || insn1 == 0xD503201F
        {
            active_function_class = None;
        }

        if (insn1 & 0x9F00001F) == 0x90000001 { // ADRP X1
            let immlo = ((insn1 >> 29) & 0x3) as i64;
            let immhi = ((insn1 >> 5) & 0x7FFFF) as i64;
            let mut imm_i64 = (immhi << 2) | immlo;
            if (imm_i64 & 0x100000) != 0 {
                imm_i64 -= 0x200000;
            }
            let page_offset = imm_i64 * 4096;
            let p_addr = ((pos & !0xFFF) as i64 + page_offset) as usize;

            let insn2 = u32::from_le_bytes(data[pos+4..pos+8].try_into().unwrap());
            if (insn2 & 0xFFC00000) == 0x91000000 { // ADD X1, X1, #imm12
                let rn = ((insn2 >> 5) & 0x1F) as usize;
                let rd = (insn2 & 0x1F) as usize;
                if rn == 1 && rd == 1 {
                    let imm12 = ((insn2 >> 10) & 0xFFF) as usize;
                    let str_addr = p_addr.wrapping_add(imm12);

                    if str_addr < data.len() {
                        if let Some(end) = data[str_addr..].iter().position(|&b| b == 0) {
                            if end >= 3 && end < 128 {
                                if let Ok(s) = std::str::from_utf8(&data[str_addr..str_addr + end]) {
                                    if s.chars().all(|c| c.is_ascii_alphanumeric() || c == '_') {
                                        let key_str = s.to_string();

                                        let owners = field_to_classes.get(&key_str);
                                        if let Some(owner_list) = owners {
                                            if active_function_class.is_none() || !owner_list.contains(active_function_class.as_ref().unwrap()) {
                                                active_function_class = Some(owner_list[0].clone());
                                            }
                                        }

                                        for offset_idx in 2..14 {
                                            let next_pos = pos + offset_idx * 4;
                                            if next_pos + 4 <= data.len() {
                                                let w_insn = u32::from_le_bytes(data[next_pos..next_pos+4].try_into().unwrap());
                                                if (w_insn & 0xFFC00000) == 0x91000000 {
                                                    let w_rn = ((w_insn >> 5) & 0x1F) as usize;
                                                    let w_rd = (w_insn & 0x1F) as usize;
                                                    let w_imm12 = ((w_insn >> 10) & 0xFFF) as usize;

                                                    if w_rn == 19 && w_rd == 2 {
                                                        let target_class = if let Some(ref afc) = active_function_class {
                                                            if classes.get(afc).map_or(false, |c| c.fields.contains_key(&key_str))
                                                                || owners.map_or(true, |o| o.contains(afc))
                                                            {
                                                                Some(afc.clone())
                                                            } else {
                                                                owners.and_then(|o| o.first().cloned())
                                                            }
                                                        } else {
                                                            owners.and_then(|o| o.first().cloned())
                                                        };

                                                        if let Some(cls_name) = target_class {
                                                            let centry = classes.entry(cls_name.clone()).or_insert_with(ClassEntry::code_only);

                                                            let inferred_type = if key_str.contains("Rank") || key_str.contains("Distance") || key_str.contains("Speed") { "float" }
                                                                        else if key_str.contains("Enabled") || key_str.contains("Active") { "bool" }
                                                                        else if key_str.contains("Id") || key_str.contains("Pool") { "string" }
                                                                        else { "int" };

                                                            let mut existing_type = None;
                                                            for (fk, fv) in centry.fields.iter() {
                                                                if fk.eq_ignore_ascii_case(&key_str) {
                                                                    if !fv.field_type.is_empty() && fv.field_type != "int" && !fv.field_type.contains("Message*") {
                                                                        existing_type = Some(fv.field_type.clone());
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                            let final_type = existing_type.unwrap_or_else(|| inferred_type.to_string());

                                                            let hex_offset = format!("0x{:X}", w_imm12);

                                                            let existing_key = if centry.fields.contains_key(&key_str) {
                                                                Some(key_str.clone())
                                                            } else {
                                                                centry.fields.keys().find(|k| k.eq_ignore_ascii_case(&key_str)).cloned()
                                                            };

                                                            if let Some(ek) = existing_key {
                                                                if let Some(f) = centry.fields.get_mut(&ek) {
                                                                    f.offset = hex_offset;
                                                                    if f.field_type.is_empty() || f.field_type == "int" {
                                                                        f.field_type = final_type;
                                                                    }
                                                                }
                                                            } else {
                                                                centry.fields.insert(key_str.clone(), FieldInfo {
                                                                    offset: hex_offset,
                                                                    field_type: final_type,
                                                                    access: None,
                                                                });
                                                                added_count += 1;
                                                            }

                                                            scanned_class_fields.entry(cls_name).or_default().insert(key_str);
                                                        }
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        pos += 4;
    }

    println!("[*] ARM64 Scanner extracted {} dynamic field offsets.", added_count);

    // Phase 2b: Generic Automated Class Offset Shift Reconciliation (0 Hardcoded Classes / 0 Hardcoded Fields)
    reconcile_shifted_class_offsets(classes, &scanned_class_fields, &original_dwarf_offsets);
}

fn reconcile_shifted_class_offsets(
    classes: &mut HashMap<String, ClassEntry>,
    scanned_class_fields: &HashMap<String, HashSet<String>>,
    original_dwarf_offsets: &HashMap<String, HashMap<String, usize>>,
) {
    let mut total_shifted_classes = 0;

    for (cname, centry) in classes.iter_mut() {
        if centry.kind.as_deref() == Some("union") {
            continue;
        }

        let scanned_set = match scanned_class_fields.get(cname) {
            Some(s) if !s.is_empty() => s,
            _ => continue,
        };

        let dwarf_orig = match original_dwarf_offsets.get(cname) {
            Some(m) => m,
            None => continue,
        };

        // 1. Compare new scanned offsets vs baseline DWARF to discover shift deltas
        let mut shifts: Vec<(usize, usize, i64, String)> = Vec::new();
        for fname in scanned_set {
            if let Some(&old_off) = dwarf_orig.get(fname) {
                if let Some(finfo) = centry.fields.get(fname) {
                    if let Ok(new_off) = usize::from_str_radix(finfo.offset.trim_start_matches("0x"), 16) {
                        let delta = (new_off as i64) - (old_off as i64);
                        shifts.push((old_off, new_off, delta, fname.clone()));
                    }
                }
            }
        }

        // 2. Propagate dominant neighborhood shift delta to un-scanned private/unmapped fields
        if !shifts.is_empty() {
            shifts.sort_by_key(|s| s.0);
            let mut delta_counts: HashMap<i64, usize> = HashMap::new();
            for s in &shifts {
                if s.2 != 0 {
                    *delta_counts.entry(s.2).or_default() += 1;
                }
            }

            if let Some((&dom_delta, _)) = delta_counts.iter().max_by_key(|(_, &cnt)| cnt) {
                let min_shifted_old = shifts.iter().filter(|s| s.2 == dom_delta).map(|s| s.0).min().unwrap_or(0);
                for (fname, finfo) in centry.fields.iter_mut() {
                    if !scanned_set.contains(fname) {
                        if let Some(&old_off) = dwarf_orig.get(fname) {
                            if old_off >= min_shifted_old {
                                let shifted = (old_off as i64 + dom_delta) as usize;
                                finfo.offset = format!("0x{:X}", shifted);
                            }
                        }
                    }
                }
                total_shifted_classes += 1;
            }
        }

        // 3. Memory Overlap & Obsolete Member Pruning using C++ Struct Memory Invariant
        let mut fields_list: Vec<(usize, usize, String, FieldInfo, bool)> = Vec::new();
        for (fname, finfo) in centry.fields.iter() {
            let off = usize::from_str_radix(finfo.offset.trim_start_matches("0x"), 16).unwrap_or(usize::MAX);
            if off == usize::MAX { continue; }
            let sz = get_type_byte_size(&finfo.field_type);
            let is_scanned = scanned_set.contains(fname);
            fields_list.push((off, sz, fname.clone(), finfo.clone(), is_scanned));
        }

        // Sort by offset ascending; if offsets collide, prioritize machine-code verified fields
        fields_list.sort_by(|a, b| {
            a.0.cmp(&b.0).then_with(|| (!a.4).cmp(&(!b.4)))
        });

        let mut cleaned_fields: BTreeMap<String, FieldInfo> = BTreeMap::new();
        let mut last_end = 0;
        let mut max_extent = 0;

        for (off, sz, fname, finfo, is_scanned) in fields_list {
            if off < last_end {
                if is_scanned {
                    // Machine-code verified field takes precedence
                    cleaned_fields.insert(fname, finfo);
                    last_end = off + sz;
                    if last_end > max_extent { max_extent = last_end; }
                } else {
                    // Unverified DWARF member falls inside preceding field span -> obsolete/deleted in new version
                    continue;
                }
            } else {
                cleaned_fields.insert(fname, finfo);
                last_end = off + sz;
                if last_end > max_extent { max_extent = last_end; }
            }
        }

        centry.fields = cleaned_fields;

        // Dynamically update class sizeof if shifted members exceed previous size
        if max_extent > 0 {
            let old_sz = centry.sizeof.as_ref()
                .and_then(|s| usize::from_str_radix(s.trim_start_matches("0x"), 16).ok())
                .unwrap_or(0);
            if max_extent > old_sz {
                centry.sizeof = Some(format!("0x{:X}", max_extent));
            }
        }
    }

    println!("[*] Automated Shift Reconciliation adjusted offsets in {} classes.", total_shifted_classes);
}

fn deduplicate_all_class_fields(classes: &mut HashMap<String, ClassEntry>) {
    for (_cname, centry) in classes.iter_mut() {
        if centry.kind.as_deref() == Some("union") {
            continue;
        }

        let mut clean_fields: BTreeMap<String, FieldInfo> = BTreeMap::new();
        let mut used_offsets: HashSet<usize> = HashSet::new();

        let mut fields_vec: Vec<(String, FieldInfo)> = centry.fields.iter().map(|(k, v)| (k.clone(), v.clone())).collect();
        fields_vec.sort_by(|(na, fa), (nb, fb)| {
            let oa = usize::from_str_radix(fa.offset.trim_start_matches("0x"), 16).unwrap_or(usize::MAX);
            let ob = usize::from_str_radix(fb.offset.trim_start_matches("0x"), 16).unwrap_or(usize::MAX);
            oa.cmp(&ob)
                .then_with(|| {
                    let upper_a = na.chars().filter(|c| c.is_ascii_uppercase()).count();
                    let upper_b = nb.chars().filter(|c| c.is_ascii_uppercase()).count();
                    upper_b.cmp(&upper_a)
                })
                .then_with(|| na.len().cmp(&nb.len()))
                .then_with(|| na.cmp(nb))
        });

        for (fname, finfo) in fields_vec {
            let off = usize::from_str_radix(finfo.offset.trim_start_matches("0x"), 16).unwrap_or(usize::MAX);
            if off != usize::MAX && used_offsets.contains(&off) {
                continue;
            }
            if off != usize::MAX {
                used_offsets.insert(off);
            }
            clean_fields.insert(fname, finfo);
        }

        centry.fields = clean_fields;
    }
}

// ----------------------------------------------------------------------------
// Phase 4: All 4 Distinct File Exporters
// ----------------------------------------------------------------------------

fn export_c_struct_headers(out_dir: &Path, classes: &HashMap<String, ClassEntry>) {
    let classes_dir = out_dir.join("classes");
    if let Err(e) = fs::create_dir_all(&classes_dir) {
        eprintln!("[!] Could not create {:?}: {}", classes_dir, e);
        return;
    }

    let mut names: Vec<&String> = classes.keys().collect();
    names.sort();

    let mut used_stems: HashSet<String> = HashSet::new();
    let mut count = 0;
    let mut failed = 0;

    for qname in names {
        let centry = &classes[qname];
        let stem = claim_unique_stem(&class_file_base(qname), &mut used_stems);
        let path = classes_dir.join(format!("{}.c", stem));
        match write_class_file(&path, qname, centry) {
            Ok(()) => count += 1,
            Err(e) => {
                failed += 1;
                eprintln!("[!] Could not write {:?}: {}", path, e);
            }
        }
    }
    println!("[*] Exported {} class files to classes/ ({} failed)", count, failed);
}

fn write_class_file(path: &Path, qname: &str, c: &ClassEntry) -> std::io::Result<()> {
    let mut f = File::create(path)?;

    let ns = c.namespace.as_deref().unwrap_or("");
    let simple = if ns.is_empty() {
        qname
    } else {
        qname.strip_prefix(ns).and_then(|r| r.strip_prefix("::")).unwrap_or(qname)
    };
    let kind = c.kind.as_deref().unwrap_or("class");
    let access = c.access.as_deref().unwrap_or("public");
    let size = c.sizeof.as_deref().unwrap_or("unknown");

    writeln!(f, "// Namespace: {}", ns)?;
    let vtable_str = c.vtable.as_deref().unwrap_or("N/A (Non-Virtual Class)");
    writeln!(f, "// VTable: {} ({} virtual functions)", vtable_str, c.virtual_function_count.unwrap_or(0))?;

    if c.sizeof.is_none() && c.fields.is_empty() {
        writeln!(f, "// No layout: declared but not defined in debug info (opaque type or declaration-only build)")?;
    }
    writeln!(f, "{} {} {} // Size: {}", access, kind, simple, size)?;
    writeln!(f, "{{")?;

    if !c.fields.is_empty() {
        writeln!(f, "    // Fields")?;
        let mut sorted: Vec<(&String, &FieldInfo)> = c.fields.iter().collect();
        sorted.sort_by(|a, b| {
            let off_a = usize::from_str_radix(a.1.offset.trim_start_matches("0x"), 16).unwrap_or(usize::MAX);
            let off_b = usize::from_str_radix(b.1.offset.trim_start_matches("0x"), 16).unwrap_or(usize::MAX);
            off_a.cmp(&off_b).then_with(|| a.0.cmp(b.0))
        });
        for (fname, finfo) in sorted {
            match finfo.access.as_deref() {
                Some(acc) => writeln!(f, "    {} {} {}; // {}", acc, finfo.field_type, fname, finfo.offset)?,
                None => writeln!(f, "    {} {}; // {}", finfo.field_type, fname, finfo.offset)?,
            }
        }
    }

    writeln!(f, "}}")?;
    Ok(())
}

fn export_enums_prop(out_dir: &Path, enums: &HashMap<String, EnumEntry>) {
    let enums_dir = out_dir.join("enums");
    fs::create_dir_all(&enums_dir).unwrap_or_default();
    let prop_path = enums_dir.join("Enums.prop");

    if let Ok(mut f) = File::create(&prop_path) {
        let _ = writeln!(f, "// Extracted Enums (DWARF & Protobuf)\n");
        for (ename, eentry) in enums {
            let _ = writeln!(f, "enum {}", ename);
            let _ = writeln!(f, "{{");
            for (vname, val) in &eentry.values {
                let _ = writeln!(f, "    {} = {},", vname, val);
            }
            let _ = writeln!(f, "}}\n");
        }
        println!("[*] Exported enums/Enums.prop ({} enums)", enums.len());
    }
}

// ----------------------------------------------------------------------------
// Embedded Protobuf Parser (Extracted from binary FileDescriptorProto descriptor)
// ----------------------------------------------------------------------------

#[derive(Default, Clone)]
pub struct ProtobufExtractor {
    pub classes: HashMap<String, (usize, Vec<(String, usize, String)>)>,
    pub enums: HashMap<String, Vec<(String, i32)>>,
    pub proto_schema: String,
}

fn read_pb_varint(data: &[u8], mut pos: usize) -> (u64, usize) {
    let mut res: u64 = 0;
    let mut shift = 0;
    while pos < data.len() {
        let b = data[pos];
        pos += 1;
        res |= ((b & 0x7F) as u64) << shift;
        if (b & 0x80) == 0 { break; }
        shift += 7;
    }
    (res, pos)
}

fn parse_field_descriptor(data: &[u8]) -> Option<(String, u32, u32, u32, String)> {
    let mut cur = 0;
    let mut name = String::new();
    let mut number = 1;
    let mut ftype = 0;
    let mut label = 1;
    let mut type_name = String::new();

    while cur < data.len() {
        let (tag_wire, next) = read_pb_varint(data, cur);
        if next == cur { break; }
        cur = next;
        let field_num = tag_wire >> 3;
        let wire_type = tag_wire & 0x7;

        if wire_type == 2 {
            let (len, next) = read_pb_varint(data, cur);
            cur = next;
            let len = len as usize;
            if cur + len > data.len() { break; }
            let b = &data[cur..cur + len];
            cur += len;
            if field_num == 1 {
                if let Ok(s) = std::str::from_utf8(b) { name = s.to_string(); }
            } else if field_num == 6 {
                if let Ok(s) = std::str::from_utf8(b) { type_name = s.to_string(); }
            }
        } else if wire_type == 0 {
            let (val, next) = read_pb_varint(data, cur);
            cur = next;
            if field_num == 3 { number = val as u32; }
            else if field_num == 4 { label = val as u32; }
            else if field_num == 5 { ftype = val as u32; }
        } else { break; }
    }

    if !name.is_empty() { Some((name, number, ftype, label, type_name)) } else { None }
}

fn parse_message_descriptor(
    data: &[u8],
    classes: &mut HashMap<String, (usize, Vec<(String, usize, String)>)>,
    raw_messages: &mut Vec<(String, Vec<(String, u32, u32, u32, String)>)>,
    enums: &mut HashMap<String, Vec<(String, i32)>>,
    raw_enums: &mut Vec<(String, Vec<(String, i32)>)>,
) {
    let mut cur = 0;
    let mut name = String::new();
    let mut raw_fields = Vec::new();

    while cur < data.len() {
        let (tag_wire, next) = read_pb_varint(data, cur);
        if next == cur { break; }
        cur = next;
        let field_num = tag_wire >> 3;
        let wire_type = tag_wire & 0x7;

        if wire_type == 2 {
            let (len, next) = read_pb_varint(data, cur);
            cur = next;
            let len = len as usize;
            if cur + len > data.len() { break; }
            let b = &data[cur..cur + len];
            cur += len;

            if field_num == 1 {
                if let Ok(s) = std::str::from_utf8(b) { name = s.to_string(); }
            } else if field_num == 2 {
                if let Some(f) = parse_field_descriptor(b) {
                    raw_fields.push(f);
                }
            } else if field_num == 4 {
                // Nested message descriptor
                parse_message_descriptor(b, classes, raw_messages, enums, raw_enums);
            } else if field_num == 5 {
                // Nested enum descriptor
                parse_enum_descriptor(b, enums, raw_enums);
            }
        } else if wire_type == 0 {
            let (_, next) = read_pb_varint(data, cur);
            cur = next;
        } else { break; }
    }

    if !name.is_empty() && !raw_fields.is_empty() {
        let mut offset = 0x18;
        let mut fields = Vec::new();
        for (fname, _fnum, ftype, label, type_name) in &raw_fields {
            let tname = match *ftype {
                1 => "double", 2 => "float", 3 => "long", 4 => "ulong",
                5 => "int", 8 => "bool", 9 => "string*", 11 => "Message*",
                12 => "byte[]", 13 => "uint", 14 => "int", _ => "int",
            };
            let ctype = if !type_name.is_empty() { type_name.trim_start_matches('.') } else { tname };
            let (cs_t, fsz) = if *label == 3 {
                (if *ftype == 11 { format!("RepeatedPtrField_{}", ctype) } else { format!("RepeatedField_{}", tname) }, 24)
            } else if *ftype == 11 {
                (format!("{}*", ctype), 8)
            } else if [1, 3, 4, 9, 12].contains(ftype) {
                (tname.to_string(), 8)
            } else if [2, 5, 13, 14].contains(ftype) {
                (tname.to_string(), 4)
            } else if *ftype == 8 {
                ("bool".to_string(), 1)
            } else {
                ("int".to_string(), 4)
            };

            let align = fsz.min(8);
            if align > 1 && offset % align != 0 {
                offset += align - (offset % align);
            }
            fields.push((fname.clone(), offset, cs_t));
            offset += fsz;
        }
        classes.insert(name.clone(), (offset, fields));
        raw_messages.push((name, raw_fields));
    }
}

fn parse_enum_descriptor(
    data: &[u8],
    enums: &mut HashMap<String, Vec<(String, i32)>>,
    raw_enums: &mut Vec<(String, Vec<(String, i32)>)>,
) {
    let mut cur = 0;
    let mut name = String::new();
    let mut vals = Vec::new();

    while cur < data.len() {
        let (tag_wire, next) = read_pb_varint(data, cur);
        if next == cur { break; }
        cur = next;
        let field_num = tag_wire >> 3;
        let wire_type = tag_wire & 0x7;

        if wire_type == 2 {
            let (len, next) = read_pb_varint(data, cur);
            cur = next;
            let len = len as usize;
            if cur + len > data.len() { break; }
            let b = &data[cur..cur + len];
            cur += len;
            if field_num == 1 {
                if let Ok(s) = std::str::from_utf8(b) { name = s.to_string(); }
            } else if field_num == 2 {
                let mut v_cur = 0;
                let mut v_name = String::new();
                let mut v_num = 0;
                while v_cur < b.len() {
                    let (v_tag, v_next) = read_pb_varint(b, v_cur);
                    if v_next == v_cur { break; }
                    v_cur = v_next;
                    let v_fnum = v_tag >> 3;
                    let v_wt = v_tag & 0x7;
                    if v_wt == 2 {
                        let (v_len, v_n) = read_pb_varint(b, v_cur);
                        v_cur = v_n;
                        let v_len = v_len as usize;
                        if v_cur + v_len <= b.len() {
                            if v_fnum == 1 {
                                if let Ok(s) = std::str::from_utf8(&b[v_cur..v_cur+v_len]) { v_name = s.to_string(); }
                            }
                            v_cur += v_len;
                        }
                    } else if v_wt == 0 {
                        let (val, v_n) = read_pb_varint(b, v_cur);
                        v_cur = v_n;
                        if v_fnum == 2 { v_num = val as i32; }
                    } else { break; }
                }
                if !v_name.is_empty() { vals.push((v_name, v_num)); }
            }
        } else if wire_type == 0 {
            let (_, next) = read_pb_varint(data, cur);
            cur = next;
        } else { break; }
    }

    if !name.is_empty() && !vals.is_empty() {
        enums.insert(name.clone(), vals.clone());
        raw_enums.push((name, vals));
    }
}

pub fn extract_protobuf_definitions(data: &[u8]) -> ProtobufExtractor {
    let mut classes = HashMap::new();
    let mut enums = HashMap::new();
    let mut raw_messages: Vec<(String, Vec<(String, u32, u32, u32, String)>)> = Vec::new();
    let mut raw_enums: Vec<(String, Vec<(String, i32)>)> = Vec::new();
    let mut package = String::new();
    let mut syntax = String::from("proto2");

    let needle = b"hcr2_messages.proto";
    let pattern = [0x0Au8, needle.len() as u8];
    let pos = data.windows(pattern.len() + needle.len()).position(|w| {
        &w[..2] == pattern && &w[2..] == needle
    });

    if let Some(p) = pos {
        let max_len = (data.len() - p).min(512 * 1024);
        let slice = &data[p..p + max_len];
        let mut cur = 0;

        while cur < slice.len() {
            let (tag_wire, next_cur) = read_pb_varint(slice, cur);
            if next_cur == cur { break; }
            cur = next_cur;
            let field_num = tag_wire >> 3;
            let wire_type = tag_wire & 0x7;

            if wire_type == 2 {
                let (len, next_cur) = read_pb_varint(slice, cur);
                cur = next_cur;
                let len = len as usize;
                if cur + len > slice.len() { break; }
                let field_bytes = &slice[cur..cur + len];
                cur += len;

                if field_num == 1 {
                    // file name
                } else if field_num == 2 {
                    if let Ok(s) = std::str::from_utf8(field_bytes) {
                        package = s.to_string();
                    }
                } else if field_num == 4 {
                    parse_message_descriptor(field_bytes, &mut classes, &mut raw_messages, &mut enums, &mut raw_enums);
                } else if field_num == 5 {
                    parse_enum_descriptor(field_bytes, &mut enums, &mut raw_enums);
                } else if field_num == 12 {
                    if let Ok(s) = std::str::from_utf8(field_bytes) {
                        syntax = s.to_string();
                    }
                }
            } else if wire_type == 0 {
                let (_, next_cur) = read_pb_varint(slice, cur);
                cur = next_cur;
            } else {
                break;
            }
        }
    }

    let mut proto_lines = Vec::new();
    proto_lines.push("// ============================================================================".to_string());
    proto_lines.push("// Reverse Engineered Protocol Buffers Schema: hcr2_messages.proto".to_string());
    proto_lines.push("// Extracted directly from embedded FileDescriptorProto descriptor (100% Rust)".to_string());
    proto_lines.push("// ============================================================================\n".to_string());
    proto_lines.push(format!("syntax = \"{}\";\n", syntax));
    if !package.is_empty() {
        proto_lines.push(format!("package {};\n", package));
    } else {
        proto_lines.push("package hcr2;\n".to_string());
    }

    for (en_name, en_vals) in &raw_enums {
        proto_lines.push(format!("enum {} {{", en_name));
        for (v_name, v_num) in en_vals {
            proto_lines.push(format!("    {} = {};", v_name, v_num));
        }
        proto_lines.push("}\n".to_string());
    }

    for (msg_name, fields) in &raw_messages {
        proto_lines.push(format!("message {} {{", msg_name));
        for (fname, fnum, ftype, label, type_name) in fields {
            let label_str = match label {
                1 => "optional",
                2 => "required",
                3 => "repeated",
                _ => "optional",
            };
            let t_str = match *ftype {
                1 => "double", 2 => "float", 3 => "int64", 4 => "uint64",
                5 => "int32", 6 => "fixed64", 7 => "fixed32", 8 => "bool",
                9 => "string", 11 => type_name.trim_start_matches('.'),
                12 => "bytes", 13 => "uint32", 14 => type_name.trim_start_matches('.'),
                15 => "sfixed32", 16 => "sfixed64", 17 => "sint32", 18 => "sint64",
                _ => "int32",
            };
            proto_lines.push(format!("    {} {} {} = {};", label_str, t_str, fname, fnum));
        }
        proto_lines.push("}\n".to_string());
    }

    let proto_schema = proto_lines.join("\n");
    println!("[*] Extracted {} Protobuf messages and {} enums from hcr2_messages.proto.", classes.len(), enums.len());
    ProtobufExtractor { classes, enums, proto_schema }
}

fn merge_protobuf_data(
    _classes: &mut HashMap<String, ClassEntry>,
    enums: &mut HashMap<String, EnumEntry>,
    pb_res: &ProtobufExtractor,
) {
    // Protobuf schemas are output strictly to hcr2_messages.proto.
    // Do NOT merge protobuf message classes into C++ classes to keep classes unpolluted.
    // Only merge authentic protobuf enums into `enums`.
    for (ename, evals) in &pb_res.enums {
        enums.entry(ename.clone()).or_insert_with(|| EnumEntry {
            name: ename.clone(),
            values: evals.iter().map(|(n, v)| (n.clone(), *v as i64)).collect(),
        });
    }
}

fn export_proto_file(out_dir: &Path, proto_schema: &str) {
    if !proto_schema.is_empty() {
        let proto_path = out_dir.join("hcr2_messages.proto");
        if let Ok(mut f) = File::create(&proto_path) {
            let _ = f.write_all(proto_schema.as_bytes());
            println!("[*] Exported authentic embedded hcr2_messages.proto ({} bytes)", proto_schema.len());
        }
    }
}

fn sanitize_user_path(raw: &str) -> String {
    let mut s = raw.trim();
    if (s.starts_with('"') && s.ends_with('"')) || (s.starts_with('\'') && s.ends_with('\'')) {
        if s.len() >= 2 {
            s = &s[1..s.len() - 1];
        }
    }
    if s.starts_with("& ") {
        s = s[2..].trim();
        if (s.starts_with('"') && s.ends_with('"')) || (s.starts_with('\'') && s.ends_with('\'')) {
            if s.len() >= 2 {
                s = &s[1..s.len() - 1];
            }
        }
    }
    s.trim().to_string()
}

fn main() {
    let raw_args: Vec<String> = std::env::args().collect();
    let is_interactive;

    if raw_args.iter().any(|a| a == "-h" || a == "--help" || a == "/?") {
        println!("Native Cocos2d C++ Schema & Offset Dumper Engine");
        println!("Supports ARM64 & x86_64 ELF | DWARF AST | RTTI VTables | Protobuf\n");
        println!("Usage:");
        println!("  dumper [TARGET_SO] [DWARF_SO] [OUTPUT_DIR]");
        println!("  dumper -r <TARGET_SO> [-d <DWARF_SO>] [-o <OUTPUT_DIR>]\n");
        println!("Arguments:");
        println!("  TARGET_SO    Path to target release .so (e.g. libcocos2dcpp.so)");
        println!("  DWARF_SO     Optional path to unstripped DWARF reference .so");
        println!("  OUTPUT_DIR   Optional output directory (default: <target_parent>/dump_output)\n");
        println!("Interactive Mode:");
        println!("  Run without arguments or double-click to drag-and-drop paths directly.");
        return;
    }

    let mut release_path_opt: Option<PathBuf> = None;
    let mut dwarf_path_opt: Option<PathBuf> = None;
    let mut out_dir_opt: Option<PathBuf> = None;

    let mut idx = 1;
    let mut positional = Vec::new();
    while idx < raw_args.len() {
        match raw_args[idx].as_str() {
            "-r" | "--release" | "--target" => {
                if idx + 1 < raw_args.len() {
                    let clean = sanitize_user_path(&raw_args[idx + 1]);
                    if !clean.is_empty() {
                        release_path_opt = Some(PathBuf::from(clean));
                    }
                    idx += 1;
                }
            }
            "-d" | "--dwarf" => {
                if idx + 1 < raw_args.len() {
                    let clean = sanitize_user_path(&raw_args[idx + 1]);
                    if !clean.is_empty() {
                        dwarf_path_opt = Some(PathBuf::from(clean));
                    }
                    idx += 1;
                }
            }
            "-o" | "--out" | "--output" => {
                if idx + 1 < raw_args.len() {
                    let clean = sanitize_user_path(&raw_args[idx + 1]);
                    if !clean.is_empty() {
                        out_dir_opt = Some(PathBuf::from(clean));
                    }
                    idx += 1;
                }
            }
            other => {
                if !other.starts_with('-') {
                    let clean = sanitize_user_path(other);
                    positional.push(clean);
                }
            }
        }
        idx += 1;
    }

    if release_path_opt.is_none() && !positional.is_empty() {
        if !positional[0].is_empty() {
            release_path_opt = Some(PathBuf::from(&positional[0]));
        }
        if positional.len() == 2 {
            let p1 = &positional[1];
            if !p1.is_empty() && (p1.ends_with(".so") || Path::new(p1).is_file()) {
                dwarf_path_opt = Some(PathBuf::from(p1));
            } else if !p1.is_empty() && p1 != "-" && p1 != "none" {
                out_dir_opt = Some(PathBuf::from(p1));
            }
        } else if positional.len() >= 3 {
            let p1 = &positional[1];
            if !p1.is_empty() && p1 != "-" && p1 != "none" && p1 != "null" {
                dwarf_path_opt = Some(PathBuf::from(p1));
            }
            if !positional[2].is_empty() {
                out_dir_opt = Some(PathBuf::from(&positional[2]));
            }
        }
    }

    let release_path;
    let dwarf_path;
    let out_dir;

    if let Some(rp) = release_path_opt {
        is_interactive = false;
        release_path = rp;
        dwarf_path = dwarf_path_opt;
        out_dir = out_dir_opt.unwrap_or_else(|| {
            release_path.parent()
                .map(|p| p.join("dump_output"))
                .unwrap_or_else(|| PathBuf::from("./dump_output"))
        });
    } else {
        is_interactive = true;
        println!("Native Cocos2d C++ Schema & Offset Dumper Engine");
        println!("Supports ARM64 & x86_64 ELF | DWARF AST | RTTI VTables | Protobuf\n");

        let target_p;
        loop {
            print!("[?] Enter target release .so path (or drag & drop file): ");
            let _ = io::stdout().flush();
            let mut line = String::new();
            if io::stdin().read_line(&mut line).is_err() {
                continue;
            }
            let clean = sanitize_user_path(&line);
            if clean.is_empty() {
                continue;
            }
            let p = PathBuf::from(&clean);
            if p.is_file() {
                target_p = p;
                break;
            } else {
                println!("[!] File not found at '{}'. Please check the path and try again.\n", clean);
            }
        }
        release_path = target_p;

        print!("[?] Enter DWARF .so reference path (optional, press Enter to skip): ");
        let _ = io::stdout().flush();
        let mut dwarf_line = String::new();
        let _ = io::stdin().read_line(&mut dwarf_line);
        let clean_dwarf = sanitize_user_path(&dwarf_line);
        if !clean_dwarf.is_empty() {
            let p = PathBuf::from(&clean_dwarf);
            if p.is_file() {
                dwarf_path = Some(p);
            } else {
                println!("[*] DWARF file not found at '{}'. Continuing in Standalone Mode.\n", clean_dwarf);
                dwarf_path = None;
            }
        } else {
            println!("[*] No DWARF reference provided. Continuing in Standalone Mode.\n");
            dwarf_path = None;
        }

        let default_out = release_path.parent()
            .map(|p| p.join("dump_output"))
            .unwrap_or_else(|| PathBuf::from("./dump_output"));
        print!("[?] Enter output directory (optional, press Enter for '{}'): ", default_out.display());
        let _ = io::stdout().flush();
        let mut out_line = String::new();
        let _ = io::stdin().read_line(&mut out_line);
        let clean_out = sanitize_user_path(&out_line);
        if !clean_out.is_empty() {
            out_dir = PathBuf::from(&clean_out);
        } else {
            out_dir = default_out;
        }
    }

    println!("\n[*] Target Binary    : {}", release_path.display());
    if let Some(ref dp) = dwarf_path {
        println!("[*] DWARF Reference  : {}", dp.display());
    } else {
        println!("[*] Mode             : Standalone (Pure Release .so Extraction)");
    }
    println!("[*] Output Directory : {}\n", out_dir.display());

    let start_time = Instant::now();
    fs::create_dir_all(&out_dir).unwrap_or_default();

    let mut classes: HashMap<String, ClassEntry> = HashMap::new();
    let mut enums: HashMap<String, EnumEntry> = HashMap::new();

    // Phase 1: DWARF AST State Machine Parsing (if provided)
    let mut dwarf_mmap_opt: Option<Mmap> = None;
    if let Some(ref dp) = dwarf_path {
        if let Ok(dwarf_file) = File::open(dp) {
            if let Ok(dwarf_mmap) = unsafe { Mmap::map(&dwarf_file) } {
                parse_dwarf_ast(&dwarf_mmap, &mut classes, &mut enums);
                dwarf_mmap_opt = Some(dwarf_mmap);
            }
        }
    }

    // Phase 2: Protobuf Extraction & ARM64 Instruction Scanning
    let mut pb_res = ProtobufExtractor::default();
    let mut rel_mmap_opt: Option<Mmap> = None;
    if let Ok(rel_file) = File::open(&release_path) {
        if let Ok(rel_mmap) = unsafe { Mmap::map(&rel_file) } {
            pb_res = extract_protobuf_definitions(&rel_mmap);
            merge_protobuf_data(&mut classes, &mut enums, &pb_res);
            scan_arm64_instructions(&rel_mmap, &mut classes);
            deduplicate_all_class_fields(&mut classes);
            rel_mmap_opt = Some(rel_mmap);
        }
    } else {
        eprintln!("[!] Error: Could not open target binary at {:?}", release_path);
        if is_interactive {
            println!("\n[*] Press Enter to exit...");
            let mut _dummy = String::new();
            let _ = io::stdin().read_line(&mut _dummy);
        }
        return;
    }

    // Phase 3: Final VTable Verification & Resolution ("find them at last")
    if let Some(ref rel_mmap) = rel_mmap_opt {
        finalize_and_verify_vtables(&mut classes, rel_mmap, dwarf_mmap_opt.as_ref());
    } else if let Some(ref dwarf_mmap) = dwarf_mmap_opt {
        finalize_and_verify_vtables(&mut classes, dwarf_mmap, None);
    }

    // Phase 4: All Complete Exporters
    let offsets_json_path = out_dir.join("offsets.json");
    if let Ok(json_str) = serde_json::to_string_pretty(&classes) {
        let _ = fs::write(&offsets_json_path, json_str);
        println!("[+] Saved dynamically reconciled offsets.json ({} classes) to {:?}", classes.len(), offsets_json_path);
    }

    export_c_struct_headers(&out_dir, &classes);
    export_enums_prop(&out_dir, &enums);
    export_proto_file(&out_dir, &pb_res.proto_schema);

    println!("[+] Process completed successfully in {:.2?}", start_time.elapsed());

    if is_interactive {
        println!("\n[*] Done! Press Enter to exit...");
        let mut _dummy = String::new();
        let _ = io::stdin().read_line(&mut _dummy);
    }
}

// ----------------------------------------------------------------------------
// JNI Entry Points for Android (.so shared library export)
// ----------------------------------------------------------------------------

#[cfg(target_os = "android")]
use jni::JNIEnv;
#[cfg(target_os = "android")]
use jni::objects::{JClass, JString};
#[cfg(target_os = "android")]
use jni::sys::jint;

#[cfg(target_os = "android")]
#[no_mangle]
pub unsafe extern "C" fn Java_com_hcr2_libdumper_NativeBridge_runReconcileEngine(
    mut env: JNIEnv,
    _class: JClass,
    so_path_obj: JString,
    dwarf_path_obj: JString,
    out_dir_obj: JString,
    _mode: jint,
    gen_classes: bool,
    gen_enums: bool,
    gen_proto: bool,
    gen_json: bool,
) -> jint {
    let so_path: String = match env.get_string(&so_path_obj) {
        Ok(s) => s.into(),
        Err(_) => return -1,
    };
    let dwarf_path: String = match env.get_string(&dwarf_path_obj) {
        Ok(s) => s.into(),
        Err(_) => String::new(),
    };
    let out_dir_str: String = match env.get_string(&out_dir_obj) {
        Ok(s) => s.into(),
        Err(_) => return -1,
    };

    let release_path = PathBuf::from(&so_path);
    let dwarf_p = PathBuf::from(&dwarf_path);
    let out_dir = PathBuf::from(&out_dir_str);

    fs::create_dir_all(&out_dir).unwrap_or_default();

    let mut classes: HashMap<String, ClassEntry> = HashMap::new();
    let mut enums: HashMap<String, EnumEntry> = HashMap::new();

    // Phase 1: True DWARF AST Parsing (Supports empty/optional DWARF gracefully)
    let mut dwarf_mmap_opt: Option<Mmap> = None;
    if !dwarf_path.is_empty() {
        if let Ok(dwarf_file) = File::open(&dwarf_p) {
            if let Ok(dwarf_mmap) = unsafe { Mmap::map(&dwarf_file) } {
                parse_dwarf_ast(&dwarf_mmap, &mut classes, &mut enums);
                dwarf_mmap_opt = Some(dwarf_mmap);
            }
        }
    }

    // Phase 2: ELF Relocation & Function-Scope Context-Tracking Instruction Scanning
    let mut pb_res = ProtobufExtractor::default();
    let mut rel_mmap_opt: Option<Mmap> = None;
    if let Ok(rel_file) = File::open(&release_path) {
        if let Ok(rel_mmap) = unsafe { Mmap::map(&rel_file) } {
            pb_res = extract_protobuf_definitions(&rel_mmap);
            merge_protobuf_data(&mut classes, &mut enums, &pb_res);
            scan_arm64_instructions(&rel_mmap, &mut classes);
            deduplicate_all_class_fields(&mut classes);
            rel_mmap_opt = Some(rel_mmap);
        }
    }

    // Phase 3: Final VTable Verification & Resolution ("find them at last")
    if let Some(ref rel_mmap) = rel_mmap_opt {
        finalize_and_verify_vtables(&mut classes, rel_mmap, dwarf_mmap_opt.as_ref());
    } else if let Some(ref dwarf_mmap) = dwarf_mmap_opt {
        finalize_and_verify_vtables(&mut classes, dwarf_mmap, None);
    }

    // Phase 4: Exports
    if gen_json {
        let offsets_json_path = out_dir.join("offsets.json");
        if let Ok(json_str) = serde_json::to_string_pretty(&classes) {
            let _ = fs::write(&offsets_json_path, json_str);
        }
    }

    if gen_classes {
        export_c_struct_headers(&out_dir, &classes);
    }

    if gen_enums {
        export_enums_prop(&out_dir, &enums);
    }

    if gen_proto {
        export_proto_file(&out_dir, &pb_res.proto_schema);
    }

    0
}

#[cfg(target_os = "android")]
use std::os::unix::io::FromRawFd;

#[cfg(target_os = "android")]
#[no_mangle]
pub unsafe extern "C" fn Java_com_hcr2_libdumper_NativeBridge_runReconcileEngineFd(
    mut env: JNIEnv,
    _class: JClass,
    target_fd: jint,
    dwarf_fd: jint,
    out_dir_obj: JString,
    _mode: jint,
    gen_classes: bool,
    gen_enums: bool,
    gen_proto: bool,
    gen_json: bool,
) -> jint {
    let out_dir_str: String = match env.get_string(&out_dir_obj) {
        Ok(s) => s.into(),
        Err(_) => return -1,
    };
    let out_dir = PathBuf::from(&out_dir_str);
    fs::create_dir_all(&out_dir).unwrap_or_default();

    let mut classes: HashMap<String, ClassEntry> = HashMap::new();
    let mut enums: HashMap<String, EnumEntry> = HashMap::new();

    let mut dwarf_mmap_opt: Option<Mmap> = None;
    if dwarf_fd > 0 {
        let dwarf_file = File::from_raw_fd(dwarf_fd);
        if let Ok(dwarf_mmap) = Mmap::map(&dwarf_file) {
            parse_dwarf_ast(&dwarf_mmap, &mut classes, &mut enums);
            dwarf_mmap_opt = Some(dwarf_mmap);
        }
        std::mem::forget(dwarf_file);
    }

    let mut pb_res = ProtobufExtractor::default();
    let mut rel_mmap_opt: Option<Mmap> = None;
    if target_fd > 0 {
        let target_file = File::from_raw_fd(target_fd);
        if let Ok(rel_mmap) = Mmap::map(&target_file) {
            pb_res = extract_protobuf_definitions(&rel_mmap);
            merge_protobuf_data(&mut classes, &mut enums, &pb_res);
            scan_arm64_instructions(&rel_mmap, &mut classes);
            deduplicate_all_class_fields(&mut classes);
            rel_mmap_opt = Some(rel_mmap);
        }
        std::mem::forget(target_file);
    }

    // Phase 3: Final VTable Verification & Resolution ("find them at last")
    if let Some(ref rel_mmap) = rel_mmap_opt {
        finalize_and_verify_vtables(&mut classes, rel_mmap, dwarf_mmap_opt.as_ref());
    } else if let Some(ref dwarf_mmap) = dwarf_mmap_opt {
        finalize_and_verify_vtables(&mut classes, dwarf_mmap, None);
    }

    if gen_json {
        let offsets_json_path = out_dir.join("offsets.json");
        if let Ok(json_str) = serde_json::to_string_pretty(&classes) {
            let _ = fs::write(&offsets_json_path, json_str);
        }
    }

    if gen_classes {
        export_c_struct_headers(&out_dir, &classes);
    }

    if gen_enums {
        export_enums_prop(&out_dir, &enums);
    }

    if gen_proto {
        export_proto_file(&out_dir, &pb_res.proto_schema);
    }

    0
}

#[cfg(target_os = "android")]
#[no_mangle]
pub unsafe extern "C" fn Java_com_hcr2_libdumper_NativeBridge_nativeDumpLibrary(
    env: JNIEnv,
    class: JClass,
    target_path_obj: JString,
    dwarf_path_obj: JString,
    out_dir_obj: JString,
    flags: jint,
) -> jint {
    let gen_json = (flags & 1) != 0;
    let gen_classes = (flags & 2) != 0;
    let gen_enums = (flags & 4) != 0;
    let gen_proto = (flags & 8) != 0;

    Java_com_hcr2_libdumper_NativeBridge_runReconcileEngine(
        env, class, target_path_obj, dwarf_path_obj, out_dir_obj, 1, gen_classes, gen_enums, gen_proto, gen_json,
    )
}
