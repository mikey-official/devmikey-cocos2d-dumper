#!/usr/bin/env bash
# Cocos2d Dumper - Universal Rust Compiler & Launcher
# Supported: Linux, macOS, Android (Termux)

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

echo "------------------------------------------------------------"
echo "  Cocos2d Dumper - Native Rust Compiler and Launcher"
echo "------------------------------------------------------------"
echo ""

# 1. Android Termux environment detection & noexec warning
if [ -d "/data/data/com.termux" ]; then
    case "$SCRIPT_DIR" in
        /sdcard*|/storage/emulated/*)
            echo "[!] WARNING: You are running from an Android shared storage mount ($SCRIPT_DIR)."
            echo "    Android storage mounts are mounted with 'noexec', which blocks compiled binaries."
            echo "    Recommended: Copy this repository to your Termux home directory (~/):"
            echo "      cp -r \"$SCRIPT_DIR\" ~/devmikey-cocos2d-dumper && cd ~/devmikey-cocos2d-dumper"
            echo ""
            ;;
    esac
fi

# 2. Source saved custom environment if previously created
if [ -f "$SCRIPT_DIR/.cargo_env" ]; then
    # shellcheck disable=SC1090
    source "$SCRIPT_DIR/.cargo_env"
fi

# 3. Check if cargo is in PATH
if command -v cargo >/dev/null 2>&1; then
    CARGO_BIN="cargo"
# 4. Check user home .cargo/bin
elif [ -f "$HOME/.cargo/bin/cargo" ]; then
    export PATH="$HOME/.cargo/bin:$PATH"
    CARGO_BIN="cargo"
# 5. Check CARGO_HOME if set
elif [ -n "$CARGO_HOME" ] && [ -f "$CARGO_HOME/bin/cargo" ]; then
    export PATH="$CARGO_HOME/bin:$PATH"
    CARGO_BIN="cargo"
# 6. Check Termux standard rust location
elif [ -f "/data/data/com.termux/files/usr/bin/cargo" ]; then
    export PATH="/data/data/com.termux/files/usr/bin:$PATH"
    CARGO_BIN="cargo"
else
    echo "[!] Rust compiler ('cargo') was not found in your environment."
    echo ""
    echo "If you installed Cargo in a custom directory (e.g. /opt/rust/bin),"
    echo "please enter the path to the directory containing 'cargo' below."
    echo "Leave empty and press Enter to install Rust automatically."
    echo ""
    read -r -p "Rust / Cargo directory (or press Enter to install): " USER_CARGO_DIR
    
    # Strip quotes
    USER_CARGO_DIR="${USER_CARGO_DIR%\"}"
    USER_CARGO_DIR="${USER_CARGO_DIR#\"}"
    USER_CARGO_DIR="${USER_CARGO_DIR%\'}"
    USER_CARGO_DIR="${USER_CARGO_DIR#\'}"

    if [ -n "$USER_CARGO_DIR" ]; then
        if [ -f "$USER_CARGO_DIR/cargo" ]; then
            SAVED_PATH="$USER_CARGO_DIR"
        elif [ -f "$USER_CARGO_DIR/bin/cargo" ]; then
            SAVED_PATH="$USER_CARGO_DIR/bin"
        else
            echo "[!] Could not find 'cargo' in '$USER_CARGO_DIR'."
            SAVED_PATH=""
        fi

        if [ -n "$SAVED_PATH" ]; then
            echo "[*] Found Cargo in: $SAVED_PATH"
            echo "export PATH=\"$SAVED_PATH:\$PATH\"" > "$SCRIPT_DIR/.cargo_env"
            export PATH="$SAVED_PATH:$PATH"
            echo "[*] Configuration saved to .cargo_env. You won't need to re-enter it!"
            echo ""
            CARGO_BIN="cargo"
        fi
    fi

    if [ -z "$CARGO_BIN" ]; then
        echo ""
        echo "To install the official Rust compiler, run:"
        echo "  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh"
        echo ""
        if [ -d "/data/data/com.termux" ]; then
            echo "On Termux, you can also install directly via:"
            echo "  pkg install rust"
            echo ""
        fi
        exit 1
    fi
fi

echo "[*] Compiling and running Cocos2d Dumper via Cargo..."
echo "[*] Working directory: $(pwd)"
echo ""
exec cargo run --release -- "$@"
